import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-basic',
  templateUrl: './form-basic.component.html',
})
export class FormBasicComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
