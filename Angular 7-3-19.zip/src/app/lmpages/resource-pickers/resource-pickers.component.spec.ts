import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResourcepickersComponent } from './resourcepickers.component';

describe('ResourcepickersComponent', () => {
  let component: ResourcepickersComponent;
  let fixture: ComponentFixture<ResourcepickersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResourcepickersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResourcepickersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
