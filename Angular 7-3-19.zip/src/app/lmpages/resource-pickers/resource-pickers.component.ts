import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resource-pickers',
  templateUrl: './resource-pickers.component.html',
  styleUrls: ['./resource-pickers.component.css']
})
export class ResourcePickersComponent implements OnInit {
  
  private msg: string;  

  constructor() { }

  ngOnInit() {
  }
  private sendDelete($event: any): void {
    this.msg = 'Delete it.'
  }
  private sendCancel($event: any): void {
    this.msg = 'Backoff!'
  }
}
