import { Component, OnInit } from '@angular/core';
import { Contact } from './contact';

import { AddserviceService } from '../../../service/addservice.service'
import { NgForm } from '@angular/forms';


@Component({
  selector: 'app-add-institutional-roles',
  templateUrl: './add-institutional-roles.component.html',
  styleUrls: ['./add-institutional-roles.component.css']
})
export class AddInstitutionalRolesComponent implements OnInit {

  languages=['English',
            'Chinese - China',
            'English - Australia',
            'English - United Kingdom',
            'Francais - Canada',
            'German - Germany',
            'Italian - Italy',
            'Portuguese - Brazil',
            'Espariol - Mexico'
          ];

          
          organizationd=[]
  organizations:Array<Contact>;

  constructor(private institutionalAddServices:AddserviceService) { }

  ngOnInit() {
  }

  onSubmit(form: NgForm){
    this.institutionalAddServices.addInstitutionalRoles(form.value)
    .subscribe(
      (Response)=>alert("Record Saved Successfully"),
      (error)=>alert("Somthing went worng")
    );
    form.reset();

  }
  onadd2(name)
  {
    let organizationss=new Contact(name);
    this.organizationd.push(organizationss);
  
  }
  onadd3(name)
  {
    let organizationss=new Contact(name);
    this.organizationd.push(organizationss);
  }
  removeOrganization(organizationd)
  {
    let index=this.organizationd.indexOf(organizationd);
    this.organizationd.splice(index,1);
  }
}
