import { Component, OnInit } from '@angular/core';
import { AddserviceService } from '../../../service/addservice.service';
import { Response } from '@angular/http';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import { Subscription } from 'rxjs/Subscription';

import { InstitutionalRoles } from '../institutionalRoles.model';
import { InstitutionalRolesService} from '../institutional-roles.service';
@Component({
  selector: 'app-view-institutional-roles',
  templateUrl: './view-institutional-roles.component.html',
  styleUrls: ['./view-institutional-roles.component.css']
})
export class ViewInstitutionalRolesComponent implements OnInit {

  institutionalroled=[
    {
    }
  ]

  institutionalrole:InstitutionalRoles[];
  institutionalroless:InstitutionalRoles;

  // disciplinesd=[
  // {
  // }
  // ];

  // disciplines:Disciplines[];
  // discipliness:Disciplines;

  subscription: Subscription;
  id:number;

  constructor(private route: ActivatedRoute,
              private institutionalrolesAdd:AddserviceService,
              private router: Router,
              private institutionalSer:InstitutionalRolesService
              ) { }

  ngOnInit() {
    this.institutionalrolesAdd.getInstitutionalRoless()
   
    this.subscription = this.institutionalSer.institutionalRolesChanged
       .subscribe(
         (terms: InstitutionalRoles[]) => {
           this.institutionalroled = terms;
         }
       );
     this.institutionalrole = this.institutionalSer.getInstitutionalRoles();
  }
//   this.disciplineServices.getDiscipliness()
//     this.subscription = this.disciplineServicess.disciplinesChanged
//       .subscribe(
//         (disciplines: Disciplines[]) => {
//           this.disciplinesd = disciplines;

//         }
//       );
//     // this.discipliness = this.disciplineServicess.getDisciplines();
//    }

 ngOnDestroy() {
    this.subscription.unsubscribe();
  }
// onDeleteCategories(){
// //   this.categoriesServices.deleteCategories(this.id);
// //   console.log(this.id)
// // console.log("deleted");
// }
// onDeleteCategorie(id:number) {
//   console.log("deleteid",id)
//     // this.courseServices.deletecategories(id).subscribe(res => {
//     //   console.log('Deleted');
//     // });
// }


}
