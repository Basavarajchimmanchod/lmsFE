import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { InstitutionalRoles } from './institutionalRoles.model';

@Injectable()
export class InstitutionalRolesService {

  institutionalRolesChanged=new Subject<InstitutionalRoles[]>();

  private institutionaldata:InstitutionalRoles[]=[
    new InstitutionalRoles(
      '','','','','','','','','','','','')
  ]
  constructor(/*private courseServices:AddserviceService*/) { }

setInstitutionalRoles(institutionalRolesdata:InstitutionalRoles[]){
  this.institutionaldata=institutionalRolesdata;
  this.institutionalRolesChanged.next(this.institutionaldata.slice());
}
getInstitutionalRoles(){
  return this.institutionaldata.slice();
}
getInstitutionalRole(index:number){
  return this.institutionaldata[index];
}
addInstitutionalRole(termsdata:InstitutionalRoles){
  this.institutionaldata.push(termsdata);
    this.institutionalRolesChanged.next(this.institutionaldata.slice());

}
updateInstitutionalRoles(index: number, newTerms:InstitutionalRoles){
  this.institutionaldata[index]=newTerms;
  //  this.courseServices.editcategories(this.categoriesdata)
  //   .subscribe(
  //     (response)=>console.log(response),
  //     (error)=>console.log(error)
  //   );
   this.institutionalRolesChanged.next(this.institutionaldata.slice());
  }

  deleteInstitutionalRoles(index:number){
    this.institutionaldata.slice(index,1);
  this.institutionalRolesChanged.next(this.institutionaldata.slice());

  }
}
