import { Component, OnInit } from '@angular/core';
import { Contact } from './contact';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';

import { InstitutionalRolesService } from '../institutional-roles.service';
import { NgForm } from '@angular/forms';
import { AddserviceService } from '../../../service/addservice.service';

@Component({
  selector: 'app-edit-institutional-roles',
  templateUrl: './edit-institutional-roles.component.html',
  styleUrls: ['./edit-institutional-roles.component.css']
})
export class EditInstitutionalRolesComponent implements OnInit {

  id: number;
  ids:number;
  editMode = false;
  institutionalRolesForm: FormGroup;

  public  idsd:number=0;

  languages=['English',
            'Chinese - China',
            'English - Australia',
            'English - United Kingdom',
            'Francais - Canada',
            'German - Germany',
            'Italian - Italy',
            'Portuguese - Brazil',
            'Espariol - Mexico'
          ]; 

          organizationd=[]
          organizations:Array<Contact>;

  constructor(private router: Router,
    private route: ActivatedRoute,
    private institutionalServ:InstitutionalRolesService,
    private institutionAddSer:AddserviceService
         ) { }

  ngOnInit() {
    this.route.params
      .subscribe(
        (params: Params) => {
          this.id = params['id'];
          this.editMode = params['id'] != null;
    this.initForm();
        }
      );
      console.log("init-id",this.id++)
       this.idsd=this.id
            console.log("init-ids----",this.idsd)

  }
  private initForm() {
    let institutionalRolesLanguage = '';
    let institutionalRolesLms  = '';
    let institutionalRolesCode = '';
    let institutionalRolesName = '';
    let institutionalRolesEffectiveDate='';
    let institutionalRolesEndDate='';

    

    if (this.editMode) {
      const institutionalRolesd = this.institutionalServ.getInstitutionalRole(this.id);
      console.log(" Edit form ",institutionalRolesd)
      institutionalRolesLanguage=institutionalRolesd.language;
      institutionalRolesLms = institutionalRolesd.lms;
      institutionalRolesCode=institutionalRolesd.code;
      institutionalRolesName=institutionalRolesd.name;
      institutionalRolesEffectiveDate=institutionalRolesd.effectiveDate;
      institutionalRolesEndDate=institutionalRolesd.endDate;
      console.log("institutionalRoles Language",institutionalRolesLanguage)
      console.log("institutionalRoles Lms",institutionalRolesLms)
      console.log("institutionalRoles Code",institutionalRolesCode)
      console.log("institutionalRoles EffectiveDate",institutionalRolesEffectiveDate)
      console.log("institutionalRoles EndDate",institutionalRolesEndDate)



  }
  this.institutionalRolesForm = new FormGroup({
      'language':new FormControl(institutionalRolesLanguage),
      'lms': new FormControl(institutionalRolesLms),
      'code':new FormControl(institutionalRolesCode),
      'name':new FormControl(institutionalRolesName),
      'effectiveDate': new FormControl(institutionalRolesEffectiveDate),
      'endDate': new FormControl(institutionalRolesEndDate),


    });
  }

onadd2(name)
{
  let organizationss=new Contact(name);
  this.organizationd.push(organizationss);

}
onadd3(name)
{
  let organizationss=new Contact(name);
  this.organizationd.push(organizationss);
}
removeOrganization(organizationd)
{
  let index=this.organizationd.indexOf(organizationd);
  this.organizationd.splice(index,1);
}
onSubmit(formName:NgForm,ids:Number){
  if(this.editMode){
    // const value=formName.value;
    // const termModel = new In(value.termName,
    //                            value.termDescription,
    //                            'value.duration',
    //                            value.startDate,
    //                            value.endDate,
    //                            'value.createBy',
    //                            'value.createDate',
    //                            'value.modifiedBy',
    //                            'value.modifiedDate',
    //                            'value.deletedBy',
    //                            'value.deletedDate');

  //  console.log("Edited Data",termModel);
  //  console.log("id fro submit",this.id);
   
       if(confirm("Do you want to save changes?")== true)
       {
         console.log("Form Data",formName);
         console.log("ids Values",this.idsd);
this.institutionAddSer.editInstitutionalRoles(formName.value,this.idsd)
   .subscribe(
     (response)=>alert("Successfully Updated"),
     (error)=>console.log(error)
   );
           this.router.navigate(['/view-Institutional-Roles']);

   }
   }
  }
}

