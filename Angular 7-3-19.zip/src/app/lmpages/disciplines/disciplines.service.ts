import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Disciplines } from './discipliness.model';

@Injectable()
export class DisciplinesService {

 disciplinesChanged=new Subject<Disciplines[]>();

  private disciplinesdata:Disciplines[]=[
    new Disciplines(
      '','','','','','','')
  ]
  constructor(/*private courseServices:AddserviceService*/) { }

setDisciplines(disciplinesdata:Disciplines[]){
  this.disciplinesdata=disciplinesdata;
  this.disciplinesChanged.next(this.disciplinesdata.slice());
}
getDisciplines(){
  return this.disciplinesdata.slice();
}
getDiscipline(index:number){
  return this.disciplinesdata[index];
}
addDiscipline(disciplinesdata:Disciplines){
  this.disciplinesdata.push(disciplinesdata);
    this.disciplinesChanged.next(this.disciplinesdata.slice());

}
updateDisciplines(index: number, newDiscipline:Disciplines){
  this.disciplinesdata[index]=newDiscipline;
  //  this.courseServices.editcategories(this.categoriesdata)
  //   .subscribe(
  //     (response)=>console.log(response),
  //     (error)=>console.log(error)
  //   );
   this.disciplinesChanged.next(this.disciplinesdata.slice());
  }

  deleteDisciplines(index:number){
    this.disciplinesdata.slice(index,1);
  this.disciplinesChanged.next(this.disciplinesdata.slice());

  }
}
