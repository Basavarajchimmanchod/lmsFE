import { Component, OnInit } from '@angular/core';
import { AddserviceService } from '../../../service/addservice.service';
import { Response } from '@angular/http';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import { Subscription } from 'rxjs/Subscription';

import { Disciplines } from '../discipliness.model';
import { DisciplinesService } from '../disciplines.service';

@Component({
  selector: 'app-view-disciplines',
  templateUrl: './view-disciplines.component.html',
  styleUrls: ['./view-disciplines.component.css']
})
export class ViewDisciplinesComponent implements OnInit {

  disciplinesd=[
  {
  }
  ];

  disciplines:Disciplines[];
  discipliness:Disciplines;

  subscription: Subscription;
  id:number;

  constructor(private disciplineServices: AddserviceService,
              private route: ActivatedRoute,
              private router: Router,
              private disciplineServicess:DisciplinesService) { }

  ngOnInit() {
  
  this.disciplineServices.getDiscipliness()
    this.subscription = this.disciplineServicess.disciplinesChanged
      .subscribe(
        (disciplines: Disciplines[]) => {
          this.disciplinesd = disciplines;

        }
      );
    // this.discipliness = this.disciplineServicess.getDisciplines();
   }

 ngOnDestroy() {
    this.subscription.unsubscribe();
  }
// onDeleteCategories(){
// //   this.categoriesServices.deleteCategories(this.id);
// //   console.log(this.id)
// // console.log("deleted");
// }
onDeleteCategorie(id:number) {
  console.log("deleteid",id)
    // this.courseServices.deletecategories(id).subscribe(res => {
    //   console.log('Deleted');
    // });
}

}
