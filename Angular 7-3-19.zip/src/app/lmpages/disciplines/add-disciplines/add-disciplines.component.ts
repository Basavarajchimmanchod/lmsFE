import { Component, OnInit } from '@angular/core';

import { AddserviceService } from '../../../service/addservice.service';
import { NgForm } from '@angular/forms';
import { Discipline } from './discipline.model'
import { Contact } from './contact';


@Component({
  selector: 'app-add-disciplines',
  templateUrl: './add-disciplines.component.html',
  styleUrls: ['./add-disciplines.component.css']
})
export class AddDisciplinesComponent implements OnInit {

  organizationd=[]
  organizations:Array<Contact>;

languages=['English',
            'Chinese - China',
            'English - Australia',
            'English - United Kingdom',
            'Francais - Canada',
            'German - Germany',
            'Italian - Italy',
            'Portuguese - Brazil',
            'Espariol - Mexico'
          ];
status=['Active','Inactive'];

  constructor(private disciplineServices: AddserviceService) { }

onSubmit(form: NgForm) {
    const value=form.value
  const DisciplineModel=new Discipline( 'value.ownerOrganization',
                                value.code,
                                value.language,
                                value.name,
                                value.description,
                                value.ordinal,
                                value.status,
                                'value.createBy',
                                'value.createDate',
                                'value.modifiedBy',
                                'value.modifiedDate',
                                'value.deletedBy',
                                'value.deletedDate'
                                )

    this.disciplineServices.addDiscipline(DisciplineModel)
    .subscribe(
      (response)=>alert("Record Saved Sucessfully"),
      (error)=>alert(error)
    );
  form.reset();
    }
  
  ngOnInit() {

  }

  
  onadd2(name)
  {
    let organizationss=new Contact(name);
    this.organizationd.push(organizationss);

  }
  onadd3(name)
  {
    let organizationss=new Contact(name);
    this.organizationd.push(organizationss);
  }
  removeOrganization(organizationd)
  {
    let index=this.organizationd.indexOf(organizationd);
    this.organizationd.splice(index,1);
  }
  
}
