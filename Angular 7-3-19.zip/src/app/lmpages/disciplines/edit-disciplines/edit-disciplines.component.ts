import { Component, OnInit } from '@angular/core';


import { ActivatedRoute, Params, Router } from '@angular/router';
import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';

import { DisciplinesService } from '../disciplines.service'
import { NgForm } from '@angular/forms';
import { AddserviceService } from '../../../service/addservice.service';
import { Discipline } from '../add-disciplines/discipline.model';
import { Contact } from './contact';


@Component({
  selector: 'app-edit-disciplines',
  templateUrl: './edit-disciplines.component.html',
  styleUrls: ['./edit-disciplines.component.css']
})
export class EditDisciplinesComponent implements OnInit {
  
  id: number;
  ids:number;
  editMode = false;
  disciplineForm: FormGroup;
  organizationd=[]
  organizations:Array<Contact>;

public  idsd:number=0;

languages=['English',
            'Chinese - China',
            'English - Australia',
            'English - United Kingdom',
            'Francais - Canada',
            'German - Germany',
            'Italian - Italy',
            'Portuguese - Brazil',
            'Espariol - Mexico'
          ];
status=['Active','Inactive'];
  constructor(private router: Router,
    private route: ActivatedRoute,
    private disciplineService:DisciplinesService,
    private disciplineAddService:AddserviceService) { }

  ngOnInit() {
    this.route.params
    .subscribe(
      (params: Params) => {
        this.id = params['id'];
        this.editMode = params['id'] != null;
  this.initForm();
      }
    );
    console.log("init-id",this.id)
     this.idsd=this.id
          console.log("init-ids----",this.idsd)

}
private initForm() {
  let disciplineCode = '';
  let disciplinelanguage  = '';
  let disciplineName = '';
  let disciplineDescription = '';
  let disciplineOrdinal='';
  let disciplineStatus='';
  
  

  if (this.editMode) {
    const disciplined = this.disciplineService.getDiscipline(this.id);
    console.log(" Edit form ",disciplined)
    disciplineCode=disciplined.code;
    disciplinelanguage = disciplined.language;
    disciplineName=disciplined.name;
    disciplineDescription=disciplined.description;
    disciplineOrdinal=disciplined.ordinal;
    disciplineStatus=disciplined.status;
    console.log("discipline code ",disciplineCode)
    console.log("discipline ")
    console.log("discipline name",disciplineName)
    console.log("discipline Description",disciplineDescription)
    console.log("discipline Ordinal",disciplineOrdinal)
    console.log("discipline Status ",disciplineStatus)
    


}
this.disciplineForm = new FormGroup({
    'code':new FormControl(disciplineCode),
    'language': new FormControl(disciplinelanguage),
    'name':new FormControl(disciplineName),
    'description': new FormControl(disciplineDescription),
    'ordinal': new FormControl(disciplineOrdinal),
    'status':new FormControl(disciplineStatus)
    

  });
}
ngAfterViewInit() {
}


onSubmit(forname:NgForm,ids:number){
  if(this.editMode){
  const value=forname.value;
   const disciplineModel = new Discipline('value.ownerOrganization',
                                            value.code,
                                            value.language,
                                            value.name,
                                            value.description,
                                            value.ordinal,
                                            value.status,
                                            'value.createBy',
                                            'value.createDate',
                                            'value.modifiedBy',
                                            'value.modifiedDate',
                                            'value.deletedBy',
                                            'value.deletedDate');

  console.log("Edited Data",disciplineModel);
  console.log("id fro submit",this.id);
  
      if(confirm("Do you want to save changes?")== true)
      {
this.disciplineAddService.editdiscipline(disciplineModel,this.id)
  .subscribe(
    (response)=>alert("Successfully Updated"),
    (error)=>console.log(error)
  );
          this.router.navigate(['/view-Discipline']);

  }
  }

}

onadd2(name)
{
  let organizationss=new Contact(name);
  this.organizationd.push(organizationss);

}
onadd3(name)
{
  let organizationss=new Contact(name);
  this.organizationd.push(organizationss);
}
removeOrganization(organizationd)
{
  let index=this.organizationd.indexOf(organizationd);
  this.organizationd.splice(index,1);
}

}
