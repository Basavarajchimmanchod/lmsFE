export class Disciplines {
    public ownerOrganization: string;
         public code:string;
         public language:string;
         public name:string;
         public description:string;
         public ordinal:string;
         public status:string;

    constructor(
         
         public ownerOrganizations: string,
         public codes:string,
         public languages:string,
         public names:string,
         public descriptions:string,
         public ordinals:string,
         public statuss:string,
          
    ) {
        this.ownerOrganization=ownerOrganizations;
        this.code=codes;
        this.language=languages;
        this.name=names;
        this.description=descriptions;
        this.ordinal=ordinals;
        this.status=statuss;
    }
}

    