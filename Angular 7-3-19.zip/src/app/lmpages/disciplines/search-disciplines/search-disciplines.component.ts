import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-disciplines',
  templateUrl: './search-disciplines.component.html',
  styleUrls: ['./search-disciplines.component.css']
})
export class SearchDisciplinesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
