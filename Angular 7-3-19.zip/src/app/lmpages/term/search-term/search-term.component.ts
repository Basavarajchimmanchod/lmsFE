import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-term',
  templateUrl: './search-term.component.html',
  styleUrls: ['./search-term.component.css']
})
export class SearchTermComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
