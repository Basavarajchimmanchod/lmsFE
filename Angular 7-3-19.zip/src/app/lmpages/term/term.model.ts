export class Terms {
           termName: string;
          termDescription:string;
          duration:string;
          startDate:string;
          endDate:string;
                 

    constructor(
         
         public termNames: string,
         public termDescriptions:string,
         public durations:string,
         public startDates:string,
         public endDates:string,
             
            
    ) {
          this.termName=termNames;
          this.termDescription=termDescriptions;
          this.duration=durations;
          this.startDate=startDates;
          this.endDate=endDates;
           
    }
}
