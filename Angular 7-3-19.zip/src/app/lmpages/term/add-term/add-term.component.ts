import { Component, OnInit } from '@angular/core';
import { ScriptLoaderService } from '../../../_services/script-loader.service';
import { Term } from './term.model';
import { HttpErrorResponse } from '@angular/common/http';
import { AddserviceService } from '../../../service/addservice.service'
import { HttpClient } from '@angular/common/http';
import 'rxjs/Rx';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-add-term',
  templateUrl: './add-term.component.html',
  styleUrls: ['./add-term.component.css']
})
export class AddTermComponent implements OnInit {

  constructor(private termServices: AddserviceService,private httpService: HttpClient) { }

  ngOnInit() {

    
  }

   onSubmit(form: NgForm) {
    const value=form.value

 const termModel = new Term(value.termName,
                                value.termDescription,
                                'value.duration',
                                value.startDate,
                                value.endDate,
                                'value.createBy',
                                'value.createDate',
                                'value.modifiedBy',
                                'value.modifiedDate',
                                'value.deletedBy',
                                'value.deletedDate');

  
    this.termServices.addTerms(termModel)
    .subscribe(
      (response)=>console.log(response),
      (error)=>console.log(error)
    );
  form.reset();
    }

}
