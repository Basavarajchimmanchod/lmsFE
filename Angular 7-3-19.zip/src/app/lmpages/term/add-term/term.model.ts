export class Term {
    constructor(
         
         public termName: string,
         public termDescription:string,
         public duration:string,
         public startDate:string,
         public endDate:string,
         public createBy : string,
         public createDate : string,
         public modifiedBy : string,
         public modifiedDate : string,
         public deletedBy : string,
         public deletedDate : string     
    ) {}
}

    