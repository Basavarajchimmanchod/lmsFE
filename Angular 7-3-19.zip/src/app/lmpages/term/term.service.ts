import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Terms } from './term.model';

@Injectable()
export class TermService {

  termsChanged=new Subject<Terms[]>();

  private termsdata:Terms[]=[
    new Terms(
      '','','','','')
  ]
  constructor(/*private courseServices:AddserviceService*/) { }

setTerms(termsdata:Terms[]){
  this.termsdata=termsdata;
  this.termsChanged.next(this.termsdata.slice());
}
getTerms(){
  return this.termsdata.slice();
}
getTerm(index:number){
  return this.termsdata[index];
}
addterm(termsdata:Terms){
  this.termsdata.push(termsdata);
    this.termsChanged.next(this.termsdata.slice());

}
updateterms(index: number, newTerms:Terms){
  this.termsdata[index]=newTerms;
  //  this.courseServices.editcategories(this.categoriesdata)
  //   .subscribe(
  //     (response)=>console.log(response),
  //     (error)=>console.log(error)
  //   );
   this.termsChanged.next(this.termsdata.slice());
  }

  deleteterms(index:number){
    this.termsdata.slice(index,1);
  this.termsChanged.next(this.termsdata.slice());

  }
}
