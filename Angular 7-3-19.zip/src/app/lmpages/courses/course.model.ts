export class Courses {

      organizations:string;
         code:string;
         name:string;
         tuition:string;
         description:string;
         targetedLearners:string;
         duration:string;
         major:string;
         deliveryMethod:string;
         approvalRequired:string;
         canRelaunch:string;
         contentType:string;
         resourceContent:string;
         selfCertifiedCompletion:string;
         courseCompletionCertificate:string;
         status:string;
         content:string;
         language:string;
         notes:string;
         courseDisplayDate:string;
         enrollmentOpenDate:string;
         enrollmentCloseDate:string;
         courseHideDate:string;
         certificationCalculationDate:string;
         daysStdToCompl:string;
         daysBeforeStdToCompl:string;
         expireDays:string;
         remindStudent:string;
         enrollmentRestriction:string;
         enrollmentDays:string;
         accumulateCredit:string;
         credit:string;
         subscriptionProgram:string;
         nonSubscriptionCanEnroll:string;
         instructionalLanguages:string;
         version:string;
         allowUseOfInterestLists:string;

    constructor(
       public organizationss:string,
        public codes:string,
        public names:string,
        public tuitions:string,
        public descriptions:string,
        public targetedLearnerss:string,
        public durations:string,
        public majors:string,
        public deliveryMethods:string,
        public approvalRequireds:string,
        public canRelaunchs:string,
        public contentTypes:string,
        public resourceContents:string,
        public selfCertifiedCompletions:string,
        public courseCompletionCertificates:string,
        public statuss:string,
        public contents:string,
        public languages:string,
        public notess:string,
        public courseDisplayDates:string,
        public enrollmentOpenDates:string,
        public enrollmentCloseDates:string,
        public courseHideDates:string,
        public certificationCalculationDates:string,
        public daysStdToCompls:string,
        public daysBeforeStdToCompls:string,
        public expireDayss:string,
        public remindStudents:string,
        public enrollmentRestrictions:string,
        public enrollmentDayss:string,
        public accumulateCredits:string,
        public credits:string,
        public subscriptionPrograms:string,
        public nonSubscriptionCanEnrolls:string,
        public instructionalLanguagess:string,
        public versions:string,
        public allowUseOfInterestListss:string,
       
    ){
         this.organizations=organizationss;
         this.code=codes;
         this.names=names;
         this.tuition=tuitions;
         this.description=descriptions;
         this.targetedLearners=targetedLearnerss;
         this.duration=durations;
         this.major=majors;
         this.deliveryMethod=deliveryMethods;
         this.approvalRequired=approvalRequireds;
         this.canRelaunch=canRelaunchs;
         this.contentType=contentTypes;
         this.resourceContent=remindStudents;
         this.selfCertifiedCompletion=selfCertifiedCompletions;
         this.courseCompletionCertificate=courseCompletionCertificates;
         this.status=statuss;
         this.content=contents;
         this.language=languages;
         this.notes=notess;
         this.courseDisplayDate=courseDisplayDates;
         this.enrollmentOpenDate=enrollmentOpenDates;
         this.enrollmentCloseDate=enrollmentCloseDates;
         this.courseHideDate=courseHideDates;
         this.certificationCalculationDate=certificationCalculationDates;
         this.daysStdToCompl=daysBeforeStdToCompls;
         this.daysBeforeStdToCompl=daysBeforeStdToCompls;
         this.expireDays=expireDayss;
         this.remindStudent=remindStudents;
         this.enrollmentRestriction=enrollmentRestrictions;
         this.enrollmentDays=enrollmentDayss;
         this.accumulateCredit=accumulateCredits;
         this.credit=credits;
         this.subscriptionProgram=subscriptionPrograms;
         this.nonSubscriptionCanEnroll=nonSubscriptionCanEnrolls;
         this.instructionalLanguages=instructionalLanguagess;
         this.version=versions;
         this.allowUseOfInterestLists=allowUseOfInterestListss;
    }
}