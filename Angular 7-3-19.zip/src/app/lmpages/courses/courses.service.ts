import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Courses } from './course.model';


@Injectable()
export class CoursesService {

coursesChanged=new Subject<Courses[]>();

  private coursesdata:Courses[]=[
    new Courses('','','','','','','','','','','','',
                '','','','','','','','','','','','',
                '','','','','','','','','','','','','')
  ]
  constructor(/*private courseServices:AddserviceService*/) { }

setCourses(coursesdata:Courses[]){
  this.coursesdata=coursesdata;
  this.coursesChanged.next(this.coursesdata.slice());
}
getCourses(){
  return this.coursesdata.slice();
}
getCourse(index:number){
  return this.coursesdata[index];
}
addContent(coursesdata:Courses){
  this.coursesdata.push(coursesdata);
    this.coursesChanged.next(this.coursesdata.slice());

}
updateContents(index: number, newCourse:Courses){
  this.coursesdata[index]=newCourse;
  //  this.courseServices.editcategories(this.categoriesdata)
  //   .subscribe(
  //     (response)=>console.log(response),
  //     (error)=>console.log(error)
  //   );
   this.coursesChanged.next(this.coursesdata.slice());
  }

  deleteContent(index:number){
    this.coursesdata.slice(index,1);
  this.coursesChanged.next(this.coursesdata.slice());

  }
}
