import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-catalog',
  templateUrl: './view-catalog.component.html',
  styleUrls: ['./view-catalog.component.css']
})
export class ViewCatalogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
