import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-catalog',
  templateUrl: './course-catalog.component.html',
  styleUrls: ['./course-catalog.component.css']
})
export class CourseCatalogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
