import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-organizations',
  templateUrl: './add-organizations.component.html',
  styleUrls: ['./add-organizations.component.css']
})
export class AddOrganizationsComponent implements OnInit {

  
  languages=['English',
            'Chinese - China',
            'English - Australia',
            'English - United Kingdom',
            'Francais - Canada',
            'German - Germany',
            'Italian - Italy',
            'Portuguese - Brazil',
            'Espariol - Mexico'
          ];
          
          country=['india',
                    'China',
                    'Australia',
                    'United Kingdom',
                    'Canada',
                    'Germany',
                    'Italy',
                    'Brazil'
          ]
          type=['Bussiness Unit',
                'Division',
                'Locale',
                'Location'

          ]
  constructor() { }

  ngOnInit() {
  }

}
