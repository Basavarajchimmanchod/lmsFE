import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-organizations',
  templateUrl: './view-organizations.component.html',
  styleUrls: ['./view-organizations.component.css']
})
export class ViewOrganizationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
