import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-organizations',
  templateUrl: './search-organizations.component.html',
  styleUrls: ['./search-organizations.component.css']
})
export class SearchOrganizationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
