export class Categoriessearch {
        public catName: string;
        public startdate:string;
        public enddate:string;
        public cont:string;
    // constructor(
    //     public catNames: string,
    //     public startdates:string,
    //     public enddates:string,
    //     public conts:string
    // ) {
    //     this.catName=catNames,
    //     this.startdate=startdates,
    //     this.enddate=enddates,
    //     this.cont=conts
    // }
}
