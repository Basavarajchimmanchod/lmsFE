export class Contact{
    // name: string[];

    constructor(public name:string){
        // this.name=name;
    }

}