export class SystemRoles{
           
    constructor(
              public language:string,
              public organization:string,
              public roleId:string,
              public rolename:string,
              public effectivedate:string,
              public enddate:string,
              public createBy:string,
              public createDate:string,
              public modifiedBy:string,
              public modifiedDate:string,
              public deletedBy:string,
              public deletedDate:string
    ){
   
    }

}
