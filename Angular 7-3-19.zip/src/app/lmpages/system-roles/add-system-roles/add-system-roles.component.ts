import { Component, OnInit } from '@angular/core';
import { Contact } from './contact';


@Component({
  selector: 'app-add-system-roles',
  templateUrl: './add-system-roles.component.html',
  styleUrls: ['./add-system-roles.component.css']
})
export class AddSystemRolesComponent implements OnInit {

  languages=['English',
            'Chinese - China',
            'English - Australia',
            'English - United Kingdom',
            'Francais - Canada',
            'German - Germany',
            'Italian - Italy',
            'Portuguese - Brazil',
            'Espariol - Mexico'
          ];

          
          organizationd=[]
  organizations:Array<Contact>;

  constructor() { }

  ngOnInit() {
  }

  
onadd2(name)
{
  let organizationss=new Contact(name);
  this.organizationd.push(organizationss);

}
onadd3(name)
{
  let organizationss=new Contact(name);
  this.organizationd.push(organizationss);
}
removeOrganization(organizationd)
{
  let index=this.organizationd.indexOf(organizationd);
  this.organizationd.splice(index,1);
}

}
