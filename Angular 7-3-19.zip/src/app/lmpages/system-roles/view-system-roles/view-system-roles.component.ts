import { Component, OnInit } from '@angular/core';
import { AddserviceService } from '../../../service/addservice.service';
import { Response } from '@angular/http';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-view-system-roles',
  templateUrl: './view-system-roles.component.html',
  styleUrls: ['./view-system-roles.component.css']
})
export class ViewSystemRolesComponent implements OnInit {

  
  subscription: Subscription;
  id:number;

  constructor(
              private route: ActivatedRoute,
              private router: Router
              ) { }

  ngOnInit() {
  }

}
