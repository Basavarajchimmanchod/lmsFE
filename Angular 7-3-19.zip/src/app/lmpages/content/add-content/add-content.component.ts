import { Component, OnInit, OnDestroy, AfterViewInit, ViewEncapsulation } from '@angular/core';

import { ScriptLoaderService } from '../../../_services/script-loader.service';
import { Response } from '@angular/http';
import { Contact } from './contact';

import { Content } from './content.model'
import { HttpErrorResponse } from '@angular/common/http';
import { AddserviceService } from '../../../service/addservice.service'
import { HttpClient } from '@angular/common/http';

import {ContentService} from '../content.service'
import { Observable, Subscription } from 'rxjs/Rx';
import { Observer } from 'rxjs/Observer';
import 'rxjs/Rx';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-add-content',
  templateUrl: './add-content.component.html',
  styleUrls: ['./add-content.component.css']
})
export class AddResourcesComponent implements OnInit, AfterViewInit {
  
  numbersObsSub:Subscription;
  customObsSub:Subscription;

  Languages=['English',
             'Chinese - China',
             'English - Australia',
             'English - United Kingdom',
             'Francais - Canada',
             'German - Germany',
             'Italian - Italy',
             'Portuguese - Brazil',
             'Espariol - Mexico'
];

types=['File',
      'Link',
      'pages'
];
  
  status=['Active','Inactive'];
  organizationd=[]
  organizations:Array<Contact>;
 // contentModel = new Contentdata('', '','','','','','','','','');
  errorMsg = '';

  public isCollapsed=true;
  constructor(private _script: ScriptLoaderService,private _courseServices: AddserviceService,private httpService: HttpClient,private _contentService:ContentService) {
  }

  ngOnInit() {

  }
  

  ngAfterViewInit() {
    this._script.load('./assets/js/scripts/form-plugins.js');
  }

  onSubmit(form: NgForm){
   

   const value=form.value;
    const contentModel = new Content(value.language, 
                                          'value.ownerOrganizations',
                                          value.name,
                                          value.type,
                                          value.discription,
                                          value.startDate,
                                          value.endDate,
                                          value.status,
                                          value.pic,
                                          value.contactName,
                                          value.contactNumber,
                                          'value.createBy',
                                          'value.createDate',
                                          'value.modifiedBy',
                                          'value.modifiedDate',
                                          'value.deletedBy',
                                          'value.deletedDate'
                                          );
     this._courseServices.addContent(contentModel)
     .subscribe(
       (response)=>alert("Record Saved Successfully"),
       (error)=>alert(error)
     );
    form.reset();
  }

  onadd2(name)
  {
    let organizationss=new Contact(name);
    this.organizationd.push(organizationss);

  }
  onadd3(name)
  {
    let organizationss=new Contact(name);
    this.organizationd.push(organizationss);
  }
  removeOrganization(organizationd)
  {
    let index=this.organizationd.indexOf(organizationd);
    this.organizationd.splice(index,1);
  }
}
