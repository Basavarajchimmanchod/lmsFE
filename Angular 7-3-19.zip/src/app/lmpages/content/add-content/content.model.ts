export class Content {
    constructor(
        public language: string,
        public ownerOrganizations: string,
        public name: string,
        public type:string,
        public discription:string,
        public startDate:string,
        public endDate:string,
        public status:string,
        public pic:string,
        public contactName:string,
        public contactNumber:string,
        public createBy : string,
         public createDate : string,
         public modifiedBy : string,
         public modifiedDate : string,
         public deletedBy : string,
         public deletedDate : string 

    ) {}
}
