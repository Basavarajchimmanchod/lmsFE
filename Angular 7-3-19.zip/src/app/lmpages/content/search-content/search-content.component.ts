import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-content',
  templateUrl: './search-content.component.html',
  styleUrls: ['./search-content.component.css']
})
export class SearchResourcesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
