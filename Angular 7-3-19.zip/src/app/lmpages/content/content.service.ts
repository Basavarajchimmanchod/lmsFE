import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Contents } from './content.model';
// import { AddserviceService } from '../../service/addservice.service'

@Injectable()
export class ContentService {

  contentChanged=new Subject<Contents[]>();

  private contentdata:Contents[]=[
    new Contents('','','','','','','','','','','')
  ]
  constructor(/*private courseServices:AddserviceService*/) { }

setContents(contentdata:Contents[]){
  this.contentdata=contentdata;
  this.contentChanged.next(this.contentdata.slice());
}
getContents(){
  return this.contentdata.slice();
}
getContent(index:number){
  return this.contentdata[index];
}
addContent(contentdata:Contents){
  this.contentdata.push(contentdata);
    this.contentChanged.next(this.contentdata.slice());

}
updateContents(index: number, newContent:Contents){
  this.contentdata[index]=newContent;
  //  this.courseServices.editcategories(this.categoriesdata)
  //   .subscribe(
  //     (response)=>console.log(response),
  //     (error)=>console.log(error)
  //   );
   this.contentChanged.next(this.contentdata.slice());
  }

  deleteContent(index:number){
    this.contentdata.slice(index,1);
  this.contentChanged.next(this.contentdata.slice());

  }
}
