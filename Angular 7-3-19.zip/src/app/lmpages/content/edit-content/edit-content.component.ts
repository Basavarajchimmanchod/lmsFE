import { Component, OnInit, OnDestroy, AfterViewInit, ViewEncapsulation } from '@angular/core';
import { ScriptLoaderService } from '../../../_services/script-loader.service';

import { ActivatedRoute, Params, Router } from '@angular/router';
import { FormGroup, FormBuilder,FormControl, FormArray, Validators } from '@angular/forms';

import { ContentService } from '../content.service';
import { NgForm } from '@angular/forms';
import { AddserviceService } from '../../../service/addservice.service'
import { Contact } from './contact';


import { Content } from '../add-content/content.model';

@Component({
  selector: 'app-edit-content',
  templateUrl: './edit-content.component.html',
  styleUrls: ['./edit-content.component.css']
})
export class EditContentComponent implements OnInit, AfterViewInit {

  id: number;
  ids:number;
  editMode = false;
  contentForm: FormGroup;
  organizationd=[]
  organizations:Array<Contact>;

public  idsd:number=0;


  languages=['English',
             'Chinese - China',
             'English - Australia',
             'English - United Kingdom',
             'Francais - Canada',
             'German - Germany',
             'Italian - Italy',
             'Portuguese - Brazil',
             'Espariol - Mexico'
];

types=['File',
      'Link',
      'pages'
];

status=['Active','Inactive'];

 public isCollapsed=true;
 constructor(private route: ActivatedRoute,
              private contentService: AddserviceService,
              private router: Router,
              private contentServicesEdit:ContentService){
  }
  
  ngOnInit() {
 this.route.params
      .subscribe(
        (params: Params) => {
          this.id = params['id'];
          this.editMode = params['id'] != null;
    this.initForm();
        }
      );
      console.log("init-id",this.id)
       this.idsd=this.id
            console.log("init-ids----",this.idsd)

  }

    private initForm(){

      let contentLanguage = '' ;
      let contentName ='';
      let contentTypes = '';
      let contentDescription = '';
      let contentStartdate='';
      let contentEnddate='';
      let contentStatus="";
      let contentFilepath='';
     let contentContactname='';
      let contentContactnumber='';

   
    if (this.editMode) {
       const contentds = this.contentServicesEdit.getContent(this.id);
      console.log(" Edit form ",contentds)
      contentLanguage=contentds.language;
      contentName = contentds.name;
      contentTypes=contentds.type;
      contentDescription=contentds.discription;
      contentStartdate=contentds.startDate;
      contentEnddate=contentds.endDate;
      contentStatus=contentds.status;
     contentFilepath=contentds.pic;
      contentContactname=contentds.contactName;
     contentContactnumber=contentds.contactNumber;
    
     // categoriesisCategorySearchable.isCategorySearchable;
     console.log("contentLanguage",contentLanguage)
          console.log("contentName",contentName)
          console.log("contenttypes",contentTypes)
          console.log("contentDescription",contentDescription)
          console.log("contentstartdate",contentStartdate)
          console.log("contentenddate",contentEnddate)
          console.log("contentstatus",contentStatus)
          console.log("contentfilepath",contentFilepath)
          console.log("contentcontactname",contentContactname)
          console.log("contentcontactnumber",contentContactnumber)



  }
  this.contentForm = new FormGroup({
      'language':new FormControl(contentLanguage),
      'name': new FormControl(contentName),
      'type':new FormControl(contentTypes),
      'discription': new FormControl(contentDescription),
      'startDate':new FormControl(contentStartdate),
      'endDate': new FormControl(contentEnddate),
      'status':new FormControl(contentStatus),
      'pic':new FormControl(""),
      // 'pic':new FormControl(contentfilepath)
      'contactname': new FormControl(contentContactname),
      'contactnumber':new FormControl(contentContactnumber)


    });
  }
  ngAfterViewInit() {
  }

  onadd2(name)
  {
    let organizationss=new Contact(name);
    this.organizationd.push(organizationss);

  }
  onadd3(name)
  {
    let organizationss=new Contact(name);
    this.organizationd.push(organizationss);
  }
  removeOrganization(organizationd)
  {
    let index=this.organizationd.indexOf(organizationd);
    this.organizationd.splice(index,1);
  }
  
  onSubmit(forname:NgForm,ids:number){
    if(this.editMode){
    

   const value=forname.value;
    const contentModel = new Content(value.language, 
                                          'value.ownerOrganizations',
                                          value.name,
                                          value.type,
                                          value.discription,
                                          value.startDate,
                                          value.endDate,
                                          value.status,
                                          value.pic,
                                          value.contactName,
                                          value.contactNumber,
                                          'value.createBy',
                                          'value.createDate',
                                          'value.modifiedBy',
                                          'value.modifiedDate',
                                          'value.deletedBy',
                                          'value.deletedDate'
                                          );
    
    forname.reset();
    console.log("Edited Data",contentModel);
    console.log("id fro submit",this.id);
    
        if(confirm("Do you want to save changes?")== true)
        {
    this.contentService.editcontents(contentModel,this.id)
     .subscribe(
       (response)=>console.log(response),
       (error)=>console.log(error)
     );
            this.router.navigate(['/view-content']);

    }
    }

  }
  
  onDeleteCategorie(){
      this.route.params
      .subscribe(
        (params: Params) => {
          this.ids = params['id'];
          this.editMode = params['id'] != null;
      // this.courseServices.deletecategories(this.ids)
  }
      );
      console.log("Delete function id",this.ids)
}
public counter : number = 0;
    
    increment(){
      this.counter += this.id;
      console.log("Counter",this.idsd )
    }
}