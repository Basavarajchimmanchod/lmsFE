export class Contentdata {
   
         Languages: string;
         owner: string;
         name: string;
         types:string;
         Description:string;
         startdate:string;
         enddate:string;
         filepath:string;
         contname:string;
         contnumber:string;

    
}
