export class Contents {
       language: string;
         ownerOrganizations: string;
         name: string;
         type:string;
         discription:string;
         startDate:string;
         endDate:string;
         status:string;
         pic:string;
         contactName:string;
         contactNumber:string;
      
    constructor(
        public languages: string,
        public ownerOrganizationss: string,
        public names: string,
        public types:string,
        public discriptions:string,
        public startDates:string,
        public endDates:string,
        public statuss:string,
        public pics:string,
        public contactNames:string,
        public contactNumbers:string
        // public createBy : string,
        //  public createDate : string,
        //  public modifiedBy : string,
        //  public modifiedDate : string,
        //  public deletedBy : string,
        //  public deletedDate : string

    ) {
           this.language= languages;
         this.ownerOrganizations= ownerOrganizationss;
         this.name= names;
         this.type=types;
         this.discription=discriptions;
         this.startDate=startDates;
         this.endDate=endDates;
         this.status=statuss;
         this.pic=pics;
         this.contactName=contactNames;
         this.contactNumber=contactNumbers;        
    }
}
