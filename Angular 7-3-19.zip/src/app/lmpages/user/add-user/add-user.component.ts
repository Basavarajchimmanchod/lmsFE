import { Component, OnInit } from '@angular/core';
import { Contact } from './contact';


@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  languages=['English',
            'Chinese - China',
            'English - Australia',
            'English - United Kingdom',
            'Francais - Canada',
            'German - Germany',
            'Italian - Italy',
            'Portuguese - Brazil',
            'Espariol - Mexico'
          ];
          
          country=['india',
                    'China',
                    'Australia',
                    'United Kingdom',
                    'Canada',
                    'Germany',
                    'Italy',
                    'Brazil'
          ]

          organizationd=[]
  organizations:Array<Contact>;

  constructor() { }

  ngOnInit() {
  }

onadd2(name)
{
  let organizationss=new Contact(name);
  this.organizationd.push(organizationss);

}
onadd3(name)
{
  let organizationss=new Contact(name);
  this.organizationd.push(organizationss);
}
removeOrganization(organizationd)
{
  let index=this.organizationd.indexOf(organizationd);
  this.organizationd.splice(index,1);
}
}
