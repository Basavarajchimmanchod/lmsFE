import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Content } from '../lmpages/content/add-content/content.model';
import { Course } from '../lmpages/courses/add-courses/courses.model';
//import { throwError } from 'rxjs';
import { ContentService } from '../lmpages/content/content.service'
import { catchError } from 'rxjs/operators';
import { _throw as throwError } from 'rxjs/observable/throw';
import { Headers, Http, Response } from '@angular/http';
import { HttpHeaders } from '@angular/common/http';
import 'rxjs/Rx';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { CategoriesService } from '../lmpages/categories/categories.service';
import { Contents} from '../lmpages/content/content.model';
import { Courses } from '../lmpages/courses/course.model';
import { Term } from '../lmpages/term/add-term/term.model';
import { Terms } from '../lmpages/term/term.model';
import { Disciplines } from '../lmpages/disciplines/discipliness.model'
import { CoursesService } from '../lmpages/courses/courses.service'
import { TermService } from '../lmpages/term/term.service';
import { DisciplinesService } from '../lmpages/disciplines/disciplines.service';
import { Discipline } from '../lmpages/disciplines/add-disciplines/discipline.model';

import { InstitutionalRoles } from '../lmpages/institutional-roles/institutionalRoles.model';
import { InstitutionalRolesService } from '../lmpages/institutional-roles/institutional-roles.service';
import { Categorie } from '../lmpages/categories/categories.model';

import { EnrollUsersService } from '../lmpages/enroll-Users/enroll-users.service';
import { EnrolledUsers } from '../lmpages/enroll-Users/enrolledUsers.model';
const httpOptions = {
   
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin':'*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS, PUT, PATCH, DELETE',
    'Access-Control-Allow-Headers': 'X-Requested-With,content-type',
    'Access-Control-Allow-Credentials':'true'
  })
};

@Injectable()
export class AddserviceService {

  private datas:Content[];
  _url;
  constructor(private _http: Http, private http : HttpClient , private ContentService:ContentService,
  private TermServicess:TermService,
  private coursesServicesn:CoursesService,
  private categoriesService:CategoriesService,
  private disciplineServices:DisciplinesService,
  private institutionalRolesser:InstitutionalRolesService,
  private enrolledUsersServices:EnrollUsersService) { }

  addcourses(courses:Course) {
    console.log("Sending Courses Data to Server");
      return this.http.post(' http://localhost:8956/coursedata',courses);
  // console.log('Course -- '+Course);
  //  return this.http.post(`http://localhost:8080` + `/addCourse`, Course);
 }

//   addcategories(Categories:Categorie) {
//     console.log("Sending Categories Data to Server ----....");
//       return this.http.post('http://localhost:8956/categoriesdata',Categories); 
//   // console.log('Categories -- '+Categories);
//   //  return this.http.post(`http://localhost:8080` + `/addCategory`, Categories);
//  }
   addContent(Contentdata:Content){
    console.log("Sending Content Data to Server ----....");
      return this.http.post('http://localhost:8956/contentdata',Contentdata);
    // console.log('Content -- '+Content);
   //  return this.http.post(`http://localhost:8080` + `/addContent`, Content);

    } 

addTerms(term:Term) {
    console.log("Sending Term Data to Server");
      return this.http.post('http://localhost:8956/termdata',term);
  // console.log('Course -- '+Course);
  //  return this.http.post(`http://localhost:8080` + `/addCourse`, Course);
 }
addDiscipline(discipline:Discipline) {
    console.log("Sending Discipline Data to Server");
      return this.http.post('http://localhost:8956/Disciplinedata',discipline);
  // console.log('Course -- '+Course);
  //  return this.http.post(`http://localhost:8080` + `/addCourse`, Course);
 }

 addInstitutionalRoles(institutionalRoles:InstitutionalRoles) {
  console.log("Sending Term Data to Server");
    return this.http.post('http://localhost:8956/InstitutionalRoles',institutionalRoles);
// console.log('Course -- '+Course);
//  return this.http.post(`http://localhost:8080` + `/addCourse`, Course);
}

getContent():Observable<any> {
  
    return this._http.get(`http://localhost:8956/Contentdata/`)
        .map((response: Response) => {
          const data=response.json();
         return data
        }
    )
    .catch((error: Response) => {
          return Observable.throw('Something went wrong');
        }
    );
}

getCategoriess():Observable<any> {
  
    return this._http.get(`http://localhost:8956/categoriesdata/`)
        .map((response: Response) => {
          const data=response.json();
         return data
        }
    )
    .catch((error: Response) => {
          return Observable.throw('Something went wrong');
        }
    );
}


getDiscipline():Observable<any> {
  
    return this._http.get(`http://localhost:8956/Disciplinedata/`)
        .map((response: Response) => {
          const data=response.json();
         return data
        }
    )
    .catch((error: Response) => {
          return Observable.throw('Something went wrong');
        }
    );
}
getCourse():Observable<any>{
   return this._http.get(`http://localhost:8956/Coursedata/`)
        .map((response: Response) => {
          const data=response.json();
         return data
        }
    )
    .catch((error: Response) => {
          return Observable.throw('Something went wrong');
        }
    );
}

// getCategorie(){
//    this._http.get('http://localhost:8956/categoriesdata/')
//       .map(
//         (response: Response) => {
//           const categorie: Categorie[] = response.json();
//           return categorie;
//         }
//       )
//       .subscribe(
//         (categorie: Categorie[]) => {
//           this.categoriesService.setCategories(categorie);
//         }
//       );
// }

getContentss(){
  this._http.get('http://localhost:8956/contentdata/')
      .map(
        (response: Response) => {
          const contentns: Contents[] = response.json();
          return contentns;
        }
      )
      .subscribe(
        (contentns: Contents[]) => {
          this.ContentService.setContents(contentns);
        }
      );

}

getInstitutionalRoless(){
  this._http.get('http://localhost:8956/InstitutionalRoles/')
      .map(
        (response: Response) => {
          const InstitutionalRolesd: InstitutionalRoles[] = response.json();
          console.log("Service Class Error",InstitutionalRolesd)
          return InstitutionalRolesd;

        }
      )
      .subscribe(
        (InstitutionalRolesd: InstitutionalRoles[]) => {
          this.institutionalRolesser.setInstitutionalRoles(InstitutionalRolesd);
        }
      );

}
getCourses(){
  this._http.get('http://localhost:8956/coursedata/')
      .map(
        (response: Response) => {
          const coursedatan: Courses[] = response.json();
          return coursedatan;
        }
      )
      .subscribe(
        (coursedatan: Courses[]) => {
          this.coursesServicesn.setCourses(coursedatan);
        }
      );
}
getTermss(){
  this._http.get('http://localhost:8956/termdata/')
      .map(
        (response: Response) => {
          const termns: Terms[] = response.json();
          return termns;
        }
      )
      .subscribe(
        (termns: Terms[]) => {
          this.TermServicess.setTerms(termns);
        }
      );

}


// getEnrolledUserss(){
//   this._http.get('http://localhost:8956/Enrollusers/')
//       .map(
//         (response: Response) => {
//           const enrolledUserData: EnrolledUsers[] = response.json();
//           return enrolledUserData;
//         }
//       )
//       .subscribe(
//         (enrolledUserData: EnrolledUsers[]) => {
//           this.enrolledUsersServices.setEnrolledUsers(enrolledUserData);
//         }
//       );

// }



getDiscipliness(){
  this._http.get('http://localhost:8956/Disciplinedata/')
      .map(
        (response: Response) => {
          const Disciplines: Disciplines[] = response.json();
          return Disciplines;
        }
      )
      .subscribe(
        (Disciplines: Disciplines[]) => {
          this.disciplineServices.setDisciplines(Disciplines);
        }
      );

}

 getContents(id:number) {
    
    return this._http.get(`http://localhost:8956/Contentdatas/${id}`)//, options)
        .map(
          (response: Response) => {
          const data:Content[]=response.json();
           return data
        }
    )
    
    .catch((error: Response) => {
          return Observable.throw('Something went wrong');
        }
    );
}

getTerms(id:number) {
    
    return this._http.get(`http://localhost:8956/termdata/${id}`)//, options)
        .map(
          (response: Response) => {
          const data:Content[]=response.json();
           return data
        }
    )
    
    .catch((error: Response) => {
          return Observable.throw('Something went wrong');
        }
    );
}


//   editcategories(Categories:Categorie,id:number) {
//     console.log("Sending Categories Data to Server ----....");
//     // return this.http.put(`http://localhost:8956/categoriesdata/`,this.categoriesService.getCategories()); 
  
//     return this.http.put(`http://localhost:8956/categoriesdata/${id}`,Categories); 
//   // console.log('Categories -- '+Categories);
//   //  return this.http.post(`http://localhost:8080` + `/addCategory`, Categories);
//  }
//  deletecategorie(id:number){
//     console.log("Sending Categories Data to Server ----....");
//       return this.http.delete(`http://localhost:8956/categoriesdata/${id}`); 
//   // console.log('Categories -- '+Categories);
//   //  return this.http.post(`http://localhost:8080` + `/addCategory`, Categories);
//  }


  editcontents(Contents:Content,id:number) {
    console.log("Sending Content Data to Server ----....");
      return this.http.put(`http://localhost:8956/contentdata/${id}`,Contents); 
  // console.log('Categories -- '+Categories);
  //  return this.http.post(`http://localhost:8080` + `/addCategory`, Categories);
 }
 deletecontent(id:number){
    console.log("Sending Content Data to Server ----....");
      return this.http.delete(`http://localhost:8956/contentdata/${id}`); 
  // console.log('Categories -- '+Categories);
  //  return this.http.post(`http://localhost:8080` + `/addCategory`, Categories);
 }

  editterm(term:Term,id:number) {
    console.log("Sending Content Data to Server ----....");
      return this.http.put(`http://localhost:8956/termdata/${id}`,term); 
  // console.log('Categories -- '+Categories);
  //  return this.http.post(`http://localhost:8080` + `/addCategory`, Categories);
 }
 deleteterm(id:number){
    console.log("Sending Content Data to Server ----....");
      return this.http.delete(`http://localhost:8956/termdata/${id}`); 
  // console.log('Categories -- '+Categories);
  //  return this.http.post(`http://localhost:8080` + `/addCategory`, Categories);
 }


  editCourse(course:Course,id:number) {
    console.log("Sending Content Data to Server ----....");
      return this.http.put(`http://localhost:8956/coursedata/${id}`,course); 
  // console.log('Categories -- '+Categories);
  //  return this.http.post(`http://localhost:8080` + `/addCategory`, Categories);
 }
 deleteCourse(id:number){
    console.log("Sending Content Data to Server ----....");
      return this.http.delete(`http://localhost:8956/coursedata/${id}`); 
  // console.log('Categories -- '+Categories);
  //  return this.http.post(`http://localhost:8080` + `/addCategory`, Categories);
 }

 editdiscipline(discipline:Discipline,id:number) {
  console.log("Sending Content Data to Server ----....");
    return this.http.put(`http://localhost:8956/termdata/${id}`,discipline); 
// console.log('Categories -- '+Categories);
//  return this.http.post(`http://localhost:8080` + `/addCategory`, Categories);
}
deletediscipline(id:number){
  console.log("Sending Content Data to Server ----....");
    return this.http.delete(`http://localhost:8956/Disciplinedata/${id}`); 
// console.log('Categories -- '+Categories);
//  return this.http.post(`http://localhost:8080` + `/addCategory`, Categories);
}

editInstitutionalRoles(institutionalRole:InstitutionalRoles,id:number) {
  console.log("Sending Content Data to Server ----....");
    return this.http.put(`http://localhost:8956/InstitutionalRoles/${id}`,institutionalRole); 
// console.log('Categories -- '+Categories);
//  return this.http.post(`http://localhost:8080` + `/addCategory`, Categories);
}
deleteInstitutionalRoles(id:number){
  console.log("Sending Content Data to Server ----....");
    return this.http.delete(`http://localhost:8956/InstitutionalRoles/${id}`); 
// console.log('Categories -- '+Categories);
//  return this.http.post(`http://localhost:8080` + `/addCategory`, Categories);
}

}
