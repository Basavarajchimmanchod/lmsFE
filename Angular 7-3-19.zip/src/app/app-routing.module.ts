import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LayoutComponent } from './/layouts/layout.component';

import { HomeComponent } from './pages/home/home.component';

import { ColorsComponent } from './pages/ui/colors/colors.component';
import { TypographyComponent } from './pages/ui/typography/typography.component';
import { PanelsComponent } from './pages/ui/panels/panels.component';
import { TabsComponent } from './pages/ui/tabs/tabs.component';
import { AlertsComponent } from './pages/ui/alerts/alerts.component';
import { CardsComponent } from './pages/ui/cards/cards.component';
import { BadgesProgressComponent } from './pages/ui/badges-progress/badges-progress.component';
import { ListComponent } from './pages/ui/list/list.component';
import { IconsComponent } from './pages/ui/icons/icons.component';
import { ButtonsComponent } from './pages/ui/buttons/buttons.component';

import { FormBasicComponent } from './pages/forms/form-basic/form-basic.component';
import { InputMasksComponent } from './pages/forms/input-masks/input-masks.component';
import { FormValidationComponent } from './pages/forms/form-validation/form-validation.component';
import { TextEditorsComponent } from './pages/forms/text-editors/text-editors.component';
import { FormAdvancedComponent } from './pages/forms/form-advanced/form-advanced.component';

import { TablesComponent } from './pages/tables/tables.component';
import { DatatablesComponent } from './pages/datatables/datatables.component';

import { ChartjsComponent } from './pages/charts/chartjs/chartjs.component';
import { MorrisChartComponent } from './pages/charts/morris-chart/morris-chart.component';
import { SparklineChartComponent } from './pages/charts/sparkline-chart/sparkline-chart.component';

import { MapsVectorComponent } from './pages/maps-vector/maps-vector.component';

import { MailboxComponent } from './pages/mailbox/mailbox/mailbox.component';
import { MailComposeComponent } from './pages/mailbox/mail-compose/mail-compose.component';
import { MailViewComponent } from './pages/mailbox/mail-view/mail-view.component';

import { CalendarComponent } from './pages/calendar/calendar.component';

import { ProfileComponent } from './pages/profile/profile.component';
import { InvoiceComponent } from './pages/invoice/invoice.component';
import { LoginComponent } from './pages/login/login.component';
import { RegisterComponent } from './pages/register/register.component';
import { ForgotPasswordComponent } from './pages/forgot-password/forgot-password.component';
import { LockscreenComponent } from './pages/lockscreen/lockscreen.component';
import { Error404Component } from './pages/error-404/error-404.component';
import { Error500Component } from './pages/error-500/error-500.component';
import { CommonModule } from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms'
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';



/*   LMS Component Begins  */
import { AdminhomeComponent } from './lmpages/adminhome/adminhome.component';

import { AddCoursesComponent } from './lmpages/courses/add-courses/add-courses.component';
import { SearchCoursesComponent } from './lmpages/courses/search-courses/search-courses.component';
import { AddResourcesComponent } from './lmpages/content/add-content/add-content.component';
import { SearchResourcesComponent } from './lmpages/content/search-content/search-content.component';
import { SearchCategoriesComponent } from './lmpages/categories/search-categories/search-categories.component';
import { AddCategoriesComponent } from './lmpages/categories/add-categories/add-categories.component';
import { ResourcePickersComponent } from './lmpages/resource-pickers/resource-pickers.component';
import { ViewCoursesComponent } from './lmpages/courses/view-courses/view-courses.component';
import { ViewContentComponent } from './lmpages/content/view-content/view-content.component';
import { ViewCatalogComponent } from './lmpages/catalog/view-catalog/view-catalog.component';
import { ViewCategoriesComponent } from './lmpages/categories/view-categories/view-categories.component';
import { EditCategoriesComponent } from './lmpages/categories/edit-categories/edit-categories.component';
import { EditContentComponent } from './lmpages/content/edit-content/edit-content.component';
import { EditCourseComponent } from './lmpages/courses/edit-course/edit-course.component';

// import { EditDataComponent } from './lmpages/content/edit-content/edit-data/edit-data.component';
import { AddTermComponent } from './lmpages/term/add-term/add-term.component';
import { ViewTermComponent } from './lmpages/term/view-term/view-term.component';
import { SearchTermComponent } from './lmpages/term/search-term/search-term.component';
import { AddDisciplinesComponent } from './lmpages/disciplines/add-disciplines/add-disciplines.component';
import { ViewDisciplinesComponent } from './lmpages/disciplines/view-disciplines/view-disciplines.component';
import { SearchDisciplinesComponent } from './lmpages/disciplines/search-disciplines/search-disciplines.component';
import { DeleteCategoriesComponent } from './lmpages/categories/delete-categories/delete-categories.component';
import { DeleteContentComponent } from './lmpages/content/delete-content/delete-content.component';
import { EditTermComponent } from './lmpages/term/edit-term/edit-term.component';
import { DeleteTermComponent } from './lmpages/term/delete-term/delete-term.component';
import { EditDisciplinesComponent } from './lmpages/disciplines/edit-disciplines/edit-disciplines.component';
import { DeleteDisciplinesComponent } from './lmpages/disciplines/delete-disciplines/delete-disciplines.component';
import { AddUserComponent } from './lmpages/user/add-user/add-user.component';
import { EditUserComponent } from './lmpages/user/edit-user/edit-user.component';
import { ViewUserComponent } from './lmpages/user/view-user/view-user.component';
import { DeleteUserComponent } from './lmpages/user/delete-user/delete-user.component';
import { SearchUserComponent } from './lmpages/user/search-user/search-user.component';
import { DeleteCoursesComponent } from './lmpages/courses/delete-courses/delete-courses.component';
import { CourseCatalogComponent } from './lmpages/catalog/course-catalog/course-catalog.component';

import { AddSystemRolesComponent } from './lmpages/system-roles/add-system-roles/add-system-roles.component';
import { EditSystemRolesComponent } from './lmpages/system-roles/edit-system-roles/edit-system-roles.component';
import { ViewSystemRolesComponent } from './lmpages/system-roles/view-system-roles/view-system-roles.component';
import { DeleteSystemRolesComponent } from './lmpages/system-roles/delete-system-roles/delete-system-roles.component';
import { SearchSystemRolesComponent } from './lmpages/system-roles/search-system-roles/search-system-roles.component';

import { AddInstitutionalRolesComponent } from './lmpages/institutional-roles/add-institutional-roles/add-institutional-roles.component';
import { ViewInstitutionalRolesComponent } from './lmpages/institutional-roles/view-institutional-roles/view-institutional-roles.component';
import { EditInstitutionalRolesComponent } from './lmpages/institutional-roles/edit-institutional-roles/edit-institutional-roles.component';
import { DeleteInstitutionalRolesComponent } from './lmpages/institutional-roles/delete-institutional-roles/delete-institutional-roles.component';
import { SearchInstitutionalRolesComponent } from './lmpages/institutional-roles/search-institutional-roles/search-institutional-roles.component';

import { AddOrganizationsComponent } from './lmpages/Organizations/add-organizations/add-organizations.component';
import { EditOrganizationsComponent } from './lmpages/Organizations/edit-organizations/edit-organizations.component';
import { ViewOrganizationsComponent } from './lmpages/Organizations/view-organizations/view-organizations.component';
import { SearchOrganizationsComponent } from './lmpages/Organizations/search-organizations/search-organizations.component';
import { DeleteOrganizationsComponent } from './lmpages/Organizations/delete-organizations/delete-organizations.component';

import { AddEnrollUsersComponent } from './lmpages/enroll-Users/add-enroll-users/add-enroll-users.component';
import { CourseDetailsComponent } from './lmpages/enroll-Users/course-details/course-details.component';
import { CourseInformationComponent} from './lmpages/enroll-Users/course-information/course-information.component';
import { EnrollUsersComponent} from './lmpages/enroll-Users/enroll-users/enroll-users.component';

/*   LMS Component ENDS  */


const routes: Routes = [
    {path: '', redirectTo: 'adminindex', pathMatch: 'full'},
    {
        "path": "",
        "component": LayoutComponent,
        "children": [
        /*   LMS Component Begins  */

            {
                path: "adminindex",
                component: AdminhomeComponent
            },
            {
                path:"add-Courses",
                component: AddCoursesComponent
            },
            {
                path:"search-Courses",
                component: SearchCoursesComponent
            },
            {
                path:"add-Resources",
                component: AddResourcesComponent
            },
            {
                path:"search-Resources",
                component: SearchResourcesComponent
            },
            {
                path:"search-Categories",
                component: SearchCategoriesComponent
            },
            {
                path:"add-Categories",
                component: AddCategoriesComponent
            },
            {
                path:"course-Catalog",
                component: CourseCatalogComponent
            },     
            {
                path:"resource-Pickers",
                component: ResourcePickersComponent
            },
           
            {
                path:"view-courses",
                component:ViewCoursesComponent
            },
            {
                path:"view-content",
                component:ViewContentComponent
            },
            {
                path:"view-Catalog",
                component:ViewCatalogComponent

            },
            {
                path:"view-Categories",
                component:ViewCategoriesComponent

            },
            {
                path:"edit-Categorie/:id",
                component:EditCategoriesComponent

            },
             {
                path:"delete-Categorie/:id",
                component:DeleteCategoriesComponent

            },
            {
                path:"add-System-Roles",
                component:AddSystemRolesComponent

            },
            {
                path:"edit-System-Roles",
                component:EditSystemRolesComponent

            },
            {
                path:"view-System-Roles",
                component:ViewSystemRolesComponent

            },
            {
                path:"delete-System-Roles",
                component:DeleteSystemRolesComponent

            },
            {
                path:"search-System-Roles",
                component:SearchSystemRolesComponent

            },
            {
                path:"add-Institutional-Roles",
                component:AddInstitutionalRolesComponent

            },
            {
                path:"edit-Institutional-Roles/:id",
                component:EditInstitutionalRolesComponent

            },
             {
                path:"view-Institutional-Roles",
                component:ViewInstitutionalRolesComponent

            },
            {
                path:"Add-Enroll-Users",
                component:AddEnrollUsersComponent

            },
            {
                path:"courses-Details",
                component:CourseDetailsComponent

            },
            {
                path:"Courses-information",
                component:CourseInformationComponent

            },
            {
                path:"enrolls-Users",
                component:EnrollUsersComponent

            },
            {
                path:"search-Institutional-Roles",
                component:SearchInstitutionalRolesComponent

            },
            {
                path:"delete-Institutional-Roles/:id",
                component:DeleteInstitutionalRolesComponent

            },
             {
                path:"edit-Term/:id",
                component:EditTermComponent

            },
            {
                path:"delete-Term/:id",
                component:DeleteTermComponent

            },
            {
                path:"add-User",
                component:AddUserComponent

            },
            {
                path:"view-User",
                component:ViewUserComponent

            },
             {
                path:"edit-User",
                component:EditUserComponent

            },
             {
                path:"search-User",
                component:SearchUserComponent

            },
             {
                path:"delete-User",
                component:DeleteUserComponent

            },
            
            {
                path:"edit-Content/:id",
                component:EditContentComponent

            },
            {
                path:"edit-discipline/:id",
                component:EditDisciplinesComponent

            },
            {
                path:"delete-Content/:id",
                component:DeleteContentComponent

            },
             {
                path:"delete-Courses/:id",
                component:DeleteCoursesComponent

            },
            
            {
                path:"delete-discipline/:id",
                component:DeleteDisciplinesComponent

            },
            
            {
                path:"edit-Course/:id",
                component:EditCourseComponent

            },
      
            {
                path:"add-Term",
                component:AddTermComponent
                
            },
            {
                path:"add-Organizations",
                component:AddOrganizationsComponent
                
            },
            {
                path:"edit-Organizations",
                component:EditOrganizationsComponent
                
            },
            {
                path:"view-Organizations",
                component:ViewOrganizationsComponent
                
            },
            {
                path:"search-Organizations",
                component:SearchOrganizationsComponent
                
            },
            {
                path:"delete-Organizations",
                component:DeleteOrganizationsComponent
                
            },
            {
                path:"view-Term",
                component:ViewTermComponent
                
            },
            {
                path:"search-Term",
                component:SearchTermComponent
                
            },
            {
                path:"add-Discipline",
                component:AddDisciplinesComponent
            },
            {
                path:"view-Discipline",
                component:ViewDisciplinesComponent
            },
            {
                path:"search-Discipline",
                component:SearchDisciplinesComponent
            },

        /*   LMS Component Ends    */

            {
                path: "index",
                component: HomeComponent
            },
            {
                path: "ui/colors",
                component: ColorsComponent
            },
            {
                path: "ui/typography",
                component: TypographyComponent
            },
            {
                path: "ui/panels",
                component: PanelsComponent
            },
            {
                path: "ui/buttons",
                component: ButtonsComponent
            },
            {
                path: "ui/tabs",
                component: TabsComponent
            },
            {
                path: "ui/alerts",
                component: AlertsComponent
            },
            {
                path: "ui/badges_progress",
                component: BadgesProgressComponent
            },
            {
                path: "ui/lists",
                component: ListComponent
            },
            {
                path: "ui/cards",
                component: CardsComponent
            },
            {
                path: "ui/icons",
                component: IconsComponent
            },
            {
                path: "forms/form_basic",
                component: FormBasicComponent
            },
            {
                path: "forms/form_advanced",
                component: FormAdvancedComponent
            },
            {
                path: "forms/form_masks",
                component: InputMasksComponent
            },
            {
                path: "forms/form_validation",
                component: FormValidationComponent
            },
            {
                path: "forms/text_editors",
                component: TextEditorsComponent
            },
            {
                path: "tables/basic",
                component: TablesComponent
            },
            {
                path: "tables/datatables",
                component: DatatablesComponent
            },
            {
                path: "charts/chartjs",
                component: ChartjsComponent
            },
            {
                path: "charts/charts_morris",
                component: MorrisChartComponent
            },
            {
                path: "charts/charts_sparkline",
                component: SparklineChartComponent
            },
            {
                path: "maps_vector",
                component: MapsVectorComponent
            },
            {
                path: "mailbox/mailbox",
                component: MailboxComponent
            },
            {
                path: "mailbox/mail_view",
                component: MailViewComponent
            },
            {
                path: "mailbox/mail_compose",
                component: MailComposeComponent
            },
            {
                path: "calendar",
                component: CalendarComponent
            },
            {
                "path": "invoice",
                "component": InvoiceComponent
            },
            {
                path: "profile",
                component: ProfileComponent
            },
            
        ]
    },
    {
        "path": "login",
        "component": LoginComponent
    },
    {
        "path": "register",
        "component": RegisterComponent
    },
    {
        "path": "lockscreen",
        "component": LockscreenComponent
    },
    {
        "path": "forgot_password",
        "component": ForgotPasswordComponent
    },
    {
        "path": "error_404",
        "component": Error404Component
    },
    {
        "path": "error_500",
        "component": Error500Component
    },
    {
        "path": "**",
        "redirectTo": "error_404",
        "pathMatch": "full"
    },
   
];

@NgModule({
  declarations: [ 
  //start lms component declaration
    AdminhomeComponent,
  //END lms component declaration
  
    HomeComponent,
    ColorsComponent,
    TypographyComponent,
    PanelsComponent,
    TabsComponent,
    AlertsComponent,
    CardsComponent,
    BadgesProgressComponent,
    ListComponent,
    IconsComponent,
    ButtonsComponent,
    FormBasicComponent,
    InputMasksComponent,
    FormValidationComponent,
    TextEditorsComponent,
    FormAdvancedComponent,
    TablesComponent,
    DatatablesComponent,
    ChartjsComponent,
    MorrisChartComponent,
    SparklineChartComponent,
    MapsVectorComponent,
    MailboxComponent,
    MailComposeComponent,
    MailViewComponent,
    CalendarComponent,
    ProfileComponent,
    InvoiceComponent,
    LoginComponent,
    RegisterComponent,
    LockscreenComponent,
    ForgotPasswordComponent,
    Error404Component,
    Error500Component,
    AddCoursesComponent,
    SearchCoursesComponent,
    AddResourcesComponent,
    SearchResourcesComponent,
    SearchCategoriesComponent,
    AddCategoriesComponent,
    ResourcePickersComponent,
    ViewCoursesComponent,
    ViewContentComponent,
    ViewCatalogComponent,
    ViewCategoriesComponent,
    EditCategoriesComponent,
    EditContentComponent,
    EditCourseComponent,
    EditTermComponent,
    EditDisciplinesComponent,
    CourseCatalogComponent,
    AddTermComponent,
    ViewTermComponent,
    SearchTermComponent,
    AddDisciplinesComponent,
    ViewDisciplinesComponent,
    SearchDisciplinesComponent,
    DeleteCategoriesComponent,
    DeleteContentComponent,
    DeleteTermComponent,
    DeleteDisciplinesComponent,
    AddUserComponent,
    EditUserComponent,
    ViewUserComponent,
    SearchUserComponent,
    DeleteUserComponent,
    DeleteCoursesComponent,
    AddSystemRolesComponent,
    EditSystemRolesComponent,
    ViewSystemRolesComponent,
    SearchSystemRolesComponent,
    DeleteSystemRolesComponent,
    AddInstitutionalRolesComponent,
    EditInstitutionalRolesComponent,
    ViewInstitutionalRolesComponent,
    SearchInstitutionalRolesComponent,
    DeleteInstitutionalRolesComponent,
    AddOrganizationsComponent,
    EditOrganizationsComponent,
    ViewOrganizationsComponent,
    SearchOrganizationsComponent,
    DeleteOrganizationsComponent,
    AddEnrollUsersComponent,
    EnrollUsersComponent,
    CourseDetailsComponent,
    CourseInformationComponent
    
  ],
  imports: [ RouterModule.forRoot(routes),
    CommonModule,
    FormsModule, ReactiveFormsModule,
    NgbModule.forRoot()
],
  exports: [ 
    RouterModule,
    
  ]
})

export class AppRoutingModule { }
