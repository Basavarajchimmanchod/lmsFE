import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './/app.component';
import { AppRoutingModule } from './/app-routing.module';
import { LayoutModule } from './/layouts/layout.module';
import { HttpClientModule } from '@angular/common/http';
import { ScriptLoaderService } from './_services/script-loader.service';
import { HttpModule } from '@angular/http';
import { CommonModule} from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import {AddserviceService} from './service/addservice.service'
import { ContentService } from './lmpages/content/content.service';


import { CategoriesService }from './lmpages/categories/categories.service';
import { TermService } from './lmpages/term/term.service';
import { CoursesService } from './lmpages/courses/courses.service';
import { DisciplinesService } from './lmpages/disciplines/disciplines.service';
import { InstitutionalRolesService } from './lmpages/institutional-roles/institutional-roles.service';

import { EnrollUsersService } from './lmpages/enroll-Users/enroll-users.service';


@NgModule({
  declarations: [
    AppComponent,
    
    ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    LayoutModule,
    HttpClientModule,
    CommonModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    
  ],
  providers: [ScriptLoaderService,
              AddserviceService,
              ContentService,
              CategoriesService,
              TermService,
              DisciplinesService,
              CoursesService,
              InstitutionalRolesService,
              EnrollUsersService
              ],
  bootstrap: [AppComponent]
})
export class AppModule { }
