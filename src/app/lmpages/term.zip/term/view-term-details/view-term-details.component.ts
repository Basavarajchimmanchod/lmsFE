import { Component, OnInit, AfterViewInit, ViewEncapsulation } from '@angular/core';
import { ScriptLoaderService } from '../../../_services/script-loader.service';

import { ActivatedRoute, Params, Router } from '@angular/router';
import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';

import { TermsService } from '../terms.service';
import { Term } from '../term.model';

import { AddserviceService } from '../../../service/addservice.service';

@Component({
  selector: 'app-view-term-details',
  templateUrl: './view-term-details.component.html',
  styleUrls: ['./view-term-details.component.css']
})
export class ViewTermDetailsComponent implements OnInit {

  id: number;
  ids:number;
  editMode = false;
  termForm: FormGroup;
  
public  idsd:number=0;
  constructor(private router: Router,
              private route: ActivatedRoute,
              private TermsSer:TermsService,
             ) { }

  ngOnInit() {
    this.route.params
      .subscribe(
        (params: Params) => {
          this.id = params['id'];
          this.editMode = params['id'] != null;
    this.initForm();
        }
      );
      console.log("init-id",this.id++)
       this.idsd=this.id
            console.log("init-ids----",this.idsd)

  }
  private initForm() {
    let termTermName = '';
    let termTermDescription  = '';
    let termStartDate ;
    let termendDate ;
    
    

    if (this.editMode) {
      const termsd = this.TermsSer.getTerm(this.id);
      console.log(" Edit form ",termsd)
      termTermName=termsd.termName;
      termTermDescription = termsd.termDescription;
      termStartDate=termsd.startDate;
      termendDate=termsd.endDate;
      console.log("Term Name",termTermName)
      console.log("Term Description",termTermDescription)
      console.log("Term StartDate",termStartDate)
      console.log("Term EndDate",termendDate)
      


  }
  this.termForm = new FormGroup({
      'termName':new FormControl(termTermName),
      'termDescription': new FormControl(termTermDescription),
      'startDate':new FormControl(termStartDate),
      'endDate': new FormControl(termendDate),
      

    });
  }
  ngAfterViewInit() {
  }


 
}