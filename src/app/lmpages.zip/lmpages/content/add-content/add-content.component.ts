import { Component, OnInit, OnDestroy, AfterViewInit, ViewEncapsulation } from '@angular/core';

import { ScriptLoaderService } from '../../../_services/script-loader.service';
import { Response } from '@angular/http';
import { MultiDataCont } from '../../../Shared/multiDataCont';

import { Content } from '../content.model'
import { HttpErrorResponse } from '@angular/common/http';
import { AddserviceService } from '../../../service/addservice.service'
import { HttpClient } from '@angular/common/http';

import {ContentService} from '../content.service'
import { Observable, Subscription } from 'rxjs/Rx';
import { Observer } from 'rxjs/Observer';
import 'rxjs/Rx';
import { NgForm } from '@angular/forms';
import { DataOrg } from '../../../Shared/dataOrg';

@Component({
  selector: 'app-add-content',
  templateUrl: './add-content.component.html',
  styleUrls: ['./add-content.component.css']
})
export class AddResourcesComponent implements OnInit, AfterViewInit {
  
  numbersObsSub:Subscription;
  customObsSub:Subscription;

  Languages=['English',
             'Chinese - China',
             'English - Australia',
             'English - United Kingdom',
             'Francais - Canada',
             'German - Germany',
             'Italian - Italy',
             'Portuguese - Brazil',
             'Espariol - Mexico'
];

types=['File',
      'Link',
      'pages'
];
  
  status=['Active','Inactive'];
  organizationd=[]
  organizations:Array<DataOrg>;
 // contentModel = new Contentdata('', '','','','','','','','','');
  errorMsg = '';
  organizationsd=[];
  public isCollapsed=true;
  constructor(private _script: ScriptLoaderService,
    private _courseServices: AddserviceService,
    private httpService: HttpClient,
    private contentService:ContentService) {
      this.organizations=[];
  }

  ngOnInit() {
    this.contentService.getOrganizations()
    .subscribe(
      (data: any[])=>{
        //console.log(data); 
        this.organizationsd=data

      },
     (error)=> console.log(error)
    );

  }
  

  ngAfterViewInit() {
    this._script.load('./assets/js/scripts/form-plugins.js');
  }

  onSubmit(form: NgForm){
   

   const value=form.value;
    const contentModel = new Content(value.language, 
                                          this.organizations,
                                          value.name,
                                          value.type,
                                          value.discription,
                                          value.startDate,
                                          value.endDate,
                                          value.status,
                                          value.pic,
                                          value.contactName,
                                          value.contactNumber,
                                          'value.createBy',
                                          'value.createDate',
                                          'value.modifiedBy',
                                          'value.modifiedDate',
                                          'value.deletedBy',
                                          'value.deletedDate'
                                          );
     this.contentService.addContents(contentModel)
     .subscribe(
       (response)=>{
         alert("Record Saved Successfully")
         this.organizations=[]
       },
       (error)=>alert(error)
     );
    form.reset();
  }

  onadd2(name)
  {
    let organization=new DataOrg(name);
    this.organizations.push(organization);
    console.log("Organization Data", this.organizations)

  }
  onadd3(name)
  {
    let organizationss=new MultiDataCont(name);
    this.organizationd.push(organizationss);
  }
  removeOrganization(organization)
  {
    let index=this.organizations.indexOf(organization);
    this.organizations.splice(index,1);
  }
}
