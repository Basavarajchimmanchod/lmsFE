import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-user-courses',
  templateUrl: './view-user-courses.component.html',
  styleUrls: ['./view-user-courses.component.css']
})
export class ViewUserCoursesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
