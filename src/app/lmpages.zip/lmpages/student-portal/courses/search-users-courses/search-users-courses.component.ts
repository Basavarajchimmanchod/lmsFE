import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-users-courses',
  templateUrl: './search-users-courses.component.html',
  styleUrls: ['./search-users-courses.component.css']
})
export class SearchUsersCoursesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
