import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-users-courses-details',
  templateUrl: './users-courses-details.component.html',
  styleUrls: ['./users-courses-details.component.css']
})
export class UsersCoursesDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
