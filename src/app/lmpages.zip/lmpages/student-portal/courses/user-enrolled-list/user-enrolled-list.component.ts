import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-enrolled-list',
  templateUrl: './user-enrolled-list.component.html',
  styleUrls: ['./user-enrolled-list.component.css']
})
export class UserEnrolledListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
