import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-user-term',
  templateUrl: './view-user-term.component.html',
  styleUrls: ['./view-user-term.component.css']
})
export class ViewUserTermComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
