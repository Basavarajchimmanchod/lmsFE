import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-term-detail',
  templateUrl: './view-term-detail.component.html',
  styleUrls: ['./view-term-detail.component.css']
})
export class ViewTermDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
