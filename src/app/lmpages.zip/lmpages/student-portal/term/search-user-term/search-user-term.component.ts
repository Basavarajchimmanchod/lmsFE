import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-user-term',
  templateUrl: './search-user-term.component.html',
  styleUrls: ['./search-user-term.component.css']
})
export class SearchUserTermComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
