import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-catalog-detail',
  templateUrl: './view-catalog-detail.component.html',
  styleUrls: ['./view-catalog-detail.component.css']
})
export class ViewCatalogDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
