import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-user-catalog',
  templateUrl: './view-user-catalog.component.html',
  styleUrls: ['./view-user-catalog.component.css']
})
export class ViewUserCatalogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
