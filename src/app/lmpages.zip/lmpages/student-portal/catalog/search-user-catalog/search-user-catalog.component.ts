import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-user-catalog',
  templateUrl: './search-user-catalog.component.html',
  styleUrls: ['./search-user-catalog.component.css']
})
export class SearchUserCatalogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
