import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-discipline-detail',
  templateUrl: './view-discipline-detail.component.html',
  styleUrls: ['./view-discipline-detail.component.css']
})
export class ViewDisciplineDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
