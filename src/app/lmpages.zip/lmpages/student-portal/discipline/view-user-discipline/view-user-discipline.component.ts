import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-user-discipline',
  templateUrl: './view-user-discipline.component.html',
  styleUrls: ['./view-user-discipline.component.css']
})
export class ViewUserDisciplineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
