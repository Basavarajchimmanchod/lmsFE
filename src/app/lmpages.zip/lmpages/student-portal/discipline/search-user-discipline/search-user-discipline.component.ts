import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-user-discipline',
  templateUrl: './search-user-discipline.component.html',
  styleUrls: ['./search-user-discipline.component.css']
})
export class SearchUserDisciplineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
