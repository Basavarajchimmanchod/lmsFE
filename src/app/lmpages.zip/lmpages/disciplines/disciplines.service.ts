import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Discipline } from '../disciplines/discipliness.model';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Headers, Http, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import { HttpHeaders } from '@angular/common/http';
import { DataOrg } from '../../Shared/dataOrg';

const httpOptions = {
   
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin':'*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS, PUT, PATCH, DELETE',
    'Access-Control-Allow-Headers': 'X-Requested-With,content-type',
    'Access-Control-Allow-Credentials':'true'
  })
};


@Injectable()
export class DisciplinesService {

 disciplinesChanged=new Subject<Discipline[]>();

  private disciplinesdata:Discipline[]=[
    new Discipline(
      [new DataOrg('')],'','','','','','','','','','','','')
  ]
  constructor(
    private _http: Http,
     private http : HttpClient /*private courseServices:AddserviceService*/) { }

setDisciplines(disciplinesdata:Discipline[]){
  this.disciplinesdata=disciplinesdata;
  this.disciplinesChanged.next(this.disciplinesdata.slice());
}
getDisciplines(){
  return this.disciplinesdata.slice();
}
getDiscipline(index:number){
  return this.disciplinesdata[index];
}
addDiscipline(disciplinesdata:Discipline){
  this.disciplinesdata.push(disciplinesdata);
    this.disciplinesChanged.next(this.disciplinesdata.slice());

}
updateDisciplines(index: number, newDiscipline:Discipline){
  this.disciplinesdata[index]=newDiscipline;
  //  this.courseServices.editcategories(this.categoriesdata)
  //   .subscribe(
  //     (response)=>console.log(response),
  //     (error)=>console.log(error)
  //   );
   this.disciplinesChanged.next(this.disciplinesdata.slice());
  }

  deleteDisciplines(index:number){
    this.disciplinesdata.slice(index,1);
  this.disciplinesChanged.next(this.disciplinesdata.slice());

  }

  addDisciplines(discipline:Discipline) {
        console.log("Sending Discipline Data to Server");
          return this.http.post('http://localhost:8956/Disciplinedata',discipline);
      // console.log('Course -- '+Course);
      //  return this.http.post(`http://localhost:8080` + `/addCourse`, Course);
     }

     getDiscipliness(){
      this._http.get('http://localhost:8956/Disciplinedata/')
          .map(
            (response: Response) => {
              const Disciplines: Discipline[] = response.json();
              return Disciplines;
            }
          )
          .subscribe(
            (Disciplines: Discipline[]) => {
              this.setDisciplines(Disciplines);
            }
          );
    
    }

    editdiscipline(discipline:Discipline,id:number) {
      console.log("Sending Content Data to Server ----....");
        return this.http.put(`http://localhost:8956/Disciplinedata/${id}`,discipline); 
    // console.log('Categories -- '+Categories);
    //  return this.http.post(`http://localhost:8080` + `/addCategory`, Categories);
    }
    
    deletediscipline(id:number){
      console.log("Sending Content Data to Server ----....");
        return this.http.delete(`http://localhost:8956/Disciplinedata/${id}`); 
    // console.log('Categories -- '+Categories);
    //  return this.http.post(`http://localhost:8080` + `/addCategory`, Categories);
    }

    getOrganizations():Observable<any> {
  
      return this._http.get(`http://localhost:8956/Organization/`)
          .map((response: Response) => {
            const data=response.json();
           return data
          }
      )
      .catch((error: Response) => {
            return Observable.throw('Something went wrong');
          }
      );
    }
}
