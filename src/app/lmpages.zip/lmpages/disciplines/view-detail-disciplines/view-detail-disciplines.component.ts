import { Component, OnInit } from '@angular/core';


import { ActivatedRoute, Params, Router } from '@angular/router';
import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';

import { DisciplinesService } from '../disciplines.service'
import { NgForm } from '@angular/forms';
import { AddserviceService } from '../../../service/addservice.service';
import { Discipline } from '../discipliness.model';
import { DataOrg } from '../../../Shared/dataOrg';


@Component({
  selector: 'app-view-detail-disciplines',
  templateUrl: './view-detail-disciplines.component.html',
  styleUrls: ['./view-detail-disciplines.component.css']
})
export class ViewDetailDisciplinesComponent implements OnInit {


  id: number;
  ids:number;
  editMode = false;
  disciplineForm: FormGroup;
  organizationd=[]
  organizations:Array<DataOrg>;

public  idsd:number=0;

languages=['English',
            'Chinese - China',
            'English - Australia',
            'English - United Kingdom',
            'Francais - Canada',
            'German - Germany',
            'Italian - Italy',
            'Portuguese - Brazil',
            'Espariol - Mexico'
          ];
status=['Active','Inactive'];
  constructor(private router: Router,
    private route: ActivatedRoute,
    private disciplineService:DisciplinesService,
    private disciplineAddService:AddserviceService)
    {
      this.organizations=[];
     }

  ngOnInit() {
    this.route.params
    .subscribe(
      (params: Params) => {
        this.id = params['id'];
        this.editMode = params['id'] != null;
  this.initForm();
      }
    );
    console.log("init-id",this.id)
     this.idsd=this.id
          console.log("init-ids----",this.idsd)

}
private initForm() {
  let disciplineOwnerOrganization =new FormArray([]);
  let disciplineCode = '';
  let disciplinelanguage  = '';
  let disciplineName = '';
  let disciplineDescription = '';
  let disciplineOrdinal='';
  let disciplineStatus='';
  
  

  if (this.editMode) {
    const disciplined = this.disciplineService.getDiscipline(this.id);
    console.log(" Edit form ",disciplined)

    if(disciplined['ownerOrganization']){
      for(let disciplinesd of disciplined.ownerOrganization){
       console.log("courses Organizations",disciplinesd.orgName)
this.organizations.push(disciplinesd);
disciplineOwnerOrganization.push(
         new FormGroup({
           'ownerOrganization':new FormControl(disciplinesd.orgName)
         })
       )
      }
    }


    disciplineCode=disciplined.code;
    disciplinelanguage = disciplined.language;
    disciplineName=disciplined.name;
    disciplineDescription=disciplined.description;
    disciplineOrdinal=disciplined.ordinal;
    disciplineStatus=disciplined.status;
    console.log("discipline code ",disciplineCode)
    console.log("discipline ")
    console.log("discipline name",disciplineName)
    console.log("discipline Description",disciplineDescription)
    console.log("discipline Ordinal",disciplineOrdinal)
    console.log("discipline Status ",disciplineStatus)
    


}
this.disciplineForm = new FormGroup({
  'ownerOrganization':disciplineOwnerOrganization,
    'code':new FormControl(disciplineCode),
    'language': new FormControl(disciplinelanguage),
    'name':new FormControl(disciplineName),
    'description': new FormControl(disciplineDescription),
    'ordinal': new FormControl(disciplineOrdinal),
    'status':new FormControl(disciplineStatus)
    

  });
}
ngAfterViewInit() {
}




}
