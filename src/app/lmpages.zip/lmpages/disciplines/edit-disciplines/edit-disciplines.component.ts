import { Component, OnInit } from '@angular/core';


import { ActivatedRoute, Params, Router } from '@angular/router';
import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';

import { DisciplinesService } from '../disciplines.service'
import { NgForm } from '@angular/forms';
import { AddserviceService } from '../../../service/addservice.service';
import { Discipline } from '../discipliness.model';
import { DataOrg } from '../../../Shared/dataOrg'

@Component({
  selector: 'app-edit-disciplines',
  templateUrl: './edit-disciplines.component.html',
  styleUrls: ['./edit-disciplines.component.css']
})
export class EditDisciplinesComponent implements OnInit {
  
  id: number;
  ids:number;
  editMode = false;
  disciplineForm: FormGroup;
  organizationd=[]
  organizations:Array<DataOrg>;

public  idsd:number=0;

languages=['English',
            'Chinese - China',
            'English - Australia',
            'English - United Kingdom',
            'Francais - Canada',
            'German - Germany',
            'Italian - Italy',
            'Portuguese - Brazil',
            'Espariol - Mexico'
          ];
status=['Active','Inactive'];
  constructor(private router: Router,
    private route: ActivatedRoute,
    private disciplineService:DisciplinesService,
    private disciplineAddService:AddserviceService)
     {
       this.organizations=[];
      }

  ngOnInit() {
    this.route.params
    .subscribe(
      (params: Params) => {
        this.id = params['id'];
        this.editMode = params['id'] != null;
  this.initForm();
      }
    );
    console.log("init-id",this.id++)
     this.idsd=this.id
          console.log("init-ids----",this.idsd)
        
          this.disciplineService.getOrganizations()
          .subscribe(
            (data: any[])=>{
              //console.log(data); 
              this.organizationd=data
      
            },
           (error)=> console.log(error)
          );



}
private initForm() {
  let disciplineOwnerOrganization =new FormArray([]);
  let disciplineCode = '';
  let disciplinelanguage  = '';
  let disciplineName = '';
  let disciplineDescription = '';
  let disciplineOrdinal='';
  let disciplineStatus='';
  
  

  if (this.editMode) {
    const disciplined = this.disciplineService.getDiscipline(this.id);
    console.log(" Edit form ",disciplined)

    if(disciplined['ownerOrganization']){
      for(let disciplinesd of disciplined.ownerOrganization){
       console.log("courses Organizations",disciplinesd.orgName)
this.organizations.push(disciplinesd);
disciplineOwnerOrganization.push(
         new FormGroup({
           'ownerOrganization':new FormControl(disciplinesd.orgName)
         })
       )
      }
    }


    disciplineCode=disciplined.code;
    disciplinelanguage = disciplined.language;
    disciplineName=disciplined.name;
    disciplineDescription=disciplined.description;
    disciplineOrdinal=disciplined.ordinal;
    disciplineStatus=disciplined.status;
    console.log("discipline code ",disciplineCode)
    console.log("discipline ")
    console.log("discipline name",disciplineName)
    console.log("discipline Description",disciplineDescription)
    console.log("discipline Ordinal",disciplineOrdinal)
    console.log("discipline Status ",disciplineStatus)
    


}
this.disciplineForm = new FormGroup({
    'ownerOrganization':disciplineOwnerOrganization,
    'code':new FormControl(disciplineCode),
    'language': new FormControl(disciplinelanguage),
    'name':new FormControl(disciplineName),
    'description': new FormControl(disciplineDescription),
    'ordinal': new FormControl(disciplineOrdinal),
    'status':new FormControl(disciplineStatus)
    

  });
}
ngAfterViewInit() {
}


onSubmit(forname:NgForm,ids:number){
  if(this.editMode){
  const value=forname.value;
   const disciplineModel = new Discipline(this.organizations,
                                            value.code,
                                            value.language,
                                            value.name,
                                            value.description,
                                            value.ordinal,
                                            value.status,
                                            'value.createBy',
                                            'value.createDate',
                                            'value.modifiedBy',
                                            'value.modifiedDate',
                                            'value.deletedBy',
                                            'value.deletedDate');

  console.log("Edited Data",disciplineModel);
  console.log("id fro submit",this.id);
  
      if(confirm("Do you want to save changes?")== true)
      {
this.disciplineService.editdiscipline(disciplineModel,this.id)
  .subscribe(
    (response)=>alert("Successfully Updated"),
    (error)=>console.log(error)
  );
          this.router.navigate(['/view-Discipline']);

  }
  }

}

onadd2(name)
{
  let organizationss=new DataOrg(name);
  this.organizationd.push(organizationss);

}
onadd3(name)
{
  let organizationss=new DataOrg(name);
  this.organizationd.push(organizationss);
}


removeOrganization(index:number)
{

  console.log("index----",index);
  (<FormArray>this.disciplineForm.get('ownerOrganization')).removeAt(index);
  this.organizations.splice(index,1);
  console.log("Form Remove index",index)
  console.log("Form Remove control",this.organizations)
  // let index=this.contacts.indexOf(contact);
  // this.contacts.splice(index,1);
}


onAddOrganization(orgName:string) {
  (<FormArray>this.disciplineForm.get('ownerOrganization')).push(
    new FormGroup({
      'ownerOrganization':new FormControl(orgName)
      // 'amount': new FormControl(null, [
      //   Validators.required,
      //   Validators.pattern(/^[1-9]+[0-9]*$/)
      // ])
    })
    
  );
  let organization=new DataOrg(orgName);
  this.organizations.push(organization)

}
}
