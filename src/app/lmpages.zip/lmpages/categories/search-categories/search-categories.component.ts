import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-categories',
  templateUrl: './search-categories.component.html',
  styleUrls: ['./search-categories.component.css']
})
export class SearchCategoriesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
