import { Component, OnInit, AfterViewInit, ViewEncapsulation } from '@angular/core';
import { ScriptLoaderService } from '../../../_services/script-loader.service';
import { MultiDataCont } from '../../../Shared/multiDataCont';

import { ActivatedRoute, Params, Router } from '@angular/router';
import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';

import { CategoriesService } from '../categories.service';
import { NgForm } from '@angular/forms';
import { AddserviceService } from '../../../service/addservice.service';

import { Categorie } from '../categories.model';

import { Subject } from 'rxjs/Subject';

@Component({
  selector: 'app-edit-categories',
  templateUrl: './edit-categories.component.html',
  styleUrls: ['./edit-categories.component.css']
})
export class EditCategoriesComponent implements OnInit, AfterViewInit {
  
  id: number;
  ids:number;
  editMode = false;
  categoriesForm: FormGroup;
  
public  idsd:number=0;
  name:string;
  contacts:Array<MultiDataCont>;
  
  languages=['English',
            'Chinese - China',
            'English - Australia',
            'English - United Kingdom',
            'Francais - Canada',
            'German - Germany',
            'Italian - Italy',
            'Portuguese - Brazil',
            'Espariol - Mexico'
          ];

  isCategorySearchable=['Yes','No'];
  status=['Active','Inactive'];


  contentss=[
    {

    }
  ]

  public isCollapsed=true;
  constructor(private _script: ScriptLoaderService,
              private router: Router,
              private route: ActivatedRoute,
              private categoriesservice:CategoriesService,
              private courseServices:AddserviceService
              ) {
    this.contacts=[];

   }
  ngOnInit() {
   this.route.params
      .subscribe(
        (params: Params) => {
          this.id = params['id'];
          this.editMode = params['id'] != null;
    this.initForm();
        }
      );
console.log("Value of contacts",this.contacts);
      this.categoriesservice.getContent()
      .subscribe(
        (data: any[])=>{
          //console.log(data); 
          this.contentss=data
  
        },
       (error)=> console.log(error)
      );
      console.log("init-id",this.id++)
       this.idsd=this.id++
            console.log("init-ids----",this.idsd)

  }
// console.log("idb  value",idb);
  private initForm() {
    let categoriesLanguage = '';
    let categoriesName = '';
    let categoriesDescription = '';
    let categoriesStartDate = '';
    let categoriesEndDate= '';
    let categoriesLms = '';
    let categoriesIsCategorySearchable = '';
    let categoriesStatus='';
    let categoriesContent= new FormArray([]);

    if (this.editMode) {
      const categoriesds = this.categoriesservice.getCategorie(this.idsd);
      console.log(" Edit form ",categoriesds)
      categoriesLanguage=categoriesds.language;
      categoriesName = categoriesds.name;
      categoriesDescription=categoriesds.description;
      categoriesStartDate=categoriesds.startDate;
      categoriesEndDate=categoriesds.endDate;
      categoriesLms=categoriesds.lms;
     categoriesIsCategorySearchable=categoriesds.isCategorySearchable;
     categoriesStatus=categoriesds.status;

     if(categoriesds['content']){
       for(let contacts of categoriesds.content){
        console.log("categoriesContent23556",contacts.contName)
this.contacts.push(contacts);
        categoriesContent.push(
          new FormGroup({
            'content':new FormControl(contacts.contName)
          })
        )
       }
     }
          // categoriesContent=categoriesds.content;
         //  // categoriesisCategorySearchable.isCategorySearchable;
    //  console.log("categorieslanguage",categoriesLanguage)
    //       console.log("categoriesname",categoriesName)
    //       console.log("categoriesdescription",categoriesDescription)
    //       console.log("categoriesstartDate",categoriesStartDate)
    //       console.log("categoriesendDate",categoriesEndDate)
    //       console.log("categorieslms",categoriesLms)
    //       console.log("categoriesisCategorySearchable",categoriesIsCategorySearchable)
          console.log("categoriesContent",this.contacts)



  }
  this.categoriesForm = new FormGroup({
      'language':new FormControl(categoriesLanguage),
      'name': new FormControl(categoriesName),
      'description': new FormControl(categoriesDescription),
      'startDate':new FormControl(categoriesStartDate),
      'endDate': new FormControl(categoriesEndDate),
      'lms': new FormControl(categoriesLms),
      'isCategorySearchable':new FormControl(categoriesIsCategorySearchable),
      'status':new FormControl(categoriesStatus),
      'content':categoriesContent

    });
  }
  ngAfterViewInit() {
    this._script.load('./assets/js/scripts/form-plugins.js');
  }


  onSubmit(forname:NgForm,ids:number){
    if(this.editMode){
      this.categoriesservice.updateCategories(this.id,forname.value)
      const categoriesdss = this.categoriesservice.getCategorie(this.id);
      console.log("Edited Data", categoriesdss)

    const value=forname.value;
     const userModel = new Categorie(value.name,
                                value.description,
                                value.language, 
                                value.startDate,
                                value.endDate,
                                value.lms,
                                value.isCategorySearchable,
                                value.status,
                                this.contacts,
                                'value.createBy',
                                'value.createDate',
                                'value.modifiedBy',
                                'value.modifiedDate',
                                'value.deletedBy',
                                'value.deletedDate');

    console.log("Edited Data",userModel);
    console.log("id fro submit",this.id);
    console.log("idsd fro  submit",this.idsd);

    
        if(confirm("Do you want to save changes?")== true)
        {
this.categoriesservice.editcategories(userModel,this.idsd)
    .subscribe(
      (response)=>alert("Successfully Updated"),
      (error)=>console.log(error)
    );

console.log("Content data " , this.contacts )
            this.router.navigate(['/view-Categories']);

    }
    }


  }

//  private increment(){
//     this.idsd += 1;
//   }
onAdd(name)
  {
   let contact=new MultiDataCont(name);
    this.contacts.push(contact);

  }
  onAddContent(name:string) {
    (<FormArray>this.categoriesForm.get('content')).push(
      new FormGroup({
        'content':new FormControl(name)
        // 'amount': new FormControl(null, [
        //   Validators.required,
        //   Validators.pattern(/^[1-9]+[0-9]*$/)
        // ])
      })
    );
    let contact=new MultiDataCont(name);
    this.contacts.push(contact)
  }

  onadd2(name)
  {
    let contact=new MultiDataCont(name);
    this.contacts.push(contact);

  }
  onadd3(name)
  {
   let contact=new MultiDataCont(name);
    this.contacts.push(contact);
  }
  addContact(Contact)
  {
    let contact=new Contact(name);
    this.contacts.push(contact);

  }
  removeContact(index:number,categoriesdar)
  {
    (<FormArray>this.categoriesForm.get('content')).removeAt(index);
    this.contacts.splice(index,1);
    console.log("Form Remove index",index)
    console.log("Form Remove control",this.contacts)
    // let index=this.contacts.indexOf(contact);
    // this.contacts.splice(index,1);
  }

  onDeleteCategorie(){
      this.route.params
      .subscribe(
        (params: Params) => {
          this.ids = params['id'];
          this.editMode = params['id'] != null;
      // this.courseServices.deletecategories(this.ids)
  }
      );
      console.log("Delete function id",this.ids)
}
// public counter : number = 0;
    
//     increment(){
//       this.counter += this.id;
//       console.log("Counter",this.idsd )
//     }
}
