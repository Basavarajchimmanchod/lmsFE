import { Component, OnInit } from '@angular/core';
import { DataOrg } from '../../../Shared/dataOrg';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';

import { InstitutionalRolesService } from '../institutional-roles.service';
import { InstitutionalRoles } from '../institutionalRoles.model';
import { NgForm } from '@angular/forms';
import { AddserviceService } from '../../../service/addservice.service';

@Component({
  selector: 'app-edit-institutional-roles',
  templateUrl: './edit-institutional-roles.component.html',
  styleUrls: ['./edit-institutional-roles.component.css']
})
export class EditInstitutionalRolesComponent implements OnInit {

  id: number;
  ids:number;
  editMode = false;
  institutionalRolesForm: FormGroup;

  
  public  idsd:number=0;

  languages=['English',
            'Chinese - China',
            'English - Australia',
            'English - United Kingdom',
            'Francais - Canada',
            'German - Germany',
            'Italian - Italy',
            'Portuguese - Brazil',
            'Espariol - Mexico'
          ]; 

          organizationd=[]
          organizations:Array<DataOrg>;

  constructor(private router: Router,
    private route: ActivatedRoute,
    private institutionalServ:InstitutionalRolesService,
    private institutionAddSer:AddserviceService
         ) {
          this.organizations=[];

          }

  ngOnInit() {
    this.route.params
      .subscribe(
        (params: Params) => {
          this.id = params['id'];
          this.editMode = params['id'] != null;
    this.initForm();
        }
      );
      console.log("init-id",this.id++)
       this.idsd=this.id
            console.log("init-ids----",this.idsd)

            this.institutionalServ.getOrganizations()
            .subscribe(
              (data: any[])=>{
                //console.log(data); 
                this.organizationd=data
        
              },
             (error)=> console.log(error)
            );

  }
  private initForm() {
    let institutionalRolesLanguage = '';
    let institutionalRolesLms  =new FormArray([]);
    let institutionalRolesCode = '';
    let institutionalRolesName = '';
    let institutionalRolesEffectiveDate='';
    let institutionalRolesEndDate='';

    

    if (this.editMode) {

      const institutionalRolesd = this.institutionalServ.getInstitutionalRole(this.id);
      console.log(" Edit form ",institutionalRolesd)


      institutionalRolesLanguage=institutionalRolesd.language;


      if(institutionalRolesd['lms']){
        for(let institutionalRole of institutionalRolesd.lms){
         console.log("courses Organizations",institutionalRole.orgName)
 this.organizations.push(institutionalRole);
 institutionalRolesLms.push(
           new FormGroup({
             'lms':new FormControl(institutionalRole.orgName)
           })
         )
        }
      }


      institutionalRolesCode=institutionalRolesd.code;
      institutionalRolesName=institutionalRolesd.name;
      institutionalRolesEffectiveDate=institutionalRolesd.effectiveDate;
      institutionalRolesEndDate=institutionalRolesd.endDate;
      console.log("institutionalRoles Language",institutionalRolesLanguage)
      console.log("institutionalRoles Lms",institutionalRolesLms)
      console.log("institutionalRoles Code",institutionalRolesCode)
      console.log("institutionalRoles EffectiveDate",institutionalRolesEffectiveDate)
      console.log("institutionalRoles EndDate",institutionalRolesEndDate)



  }
  this.institutionalRolesForm = new FormGroup({
      'language':new FormControl(institutionalRolesLanguage),
      'lms': institutionalRolesLms,
      'code':new FormControl(institutionalRolesCode),
      'name':new FormControl(institutionalRolesName),
      'effectiveDate': new FormControl(institutionalRolesEffectiveDate),
      'endDate': new FormControl(institutionalRolesEndDate),


    });
  }

onadd2(name)
{
  let organizationss=new DataOrg(name);
  this.organizations.push(organizationss);

}
onadd3(name)
{
  let organizationss=new DataOrg(name);
  this.organizationd.push(organizationss);
}
removeOrganization(index:number)
{

  console.log("index----",index);
  (<FormArray>this.institutionalRolesForm.get('lms')).removeAt(index);
  this.organizations.splice(index,1);
  console.log("Form Remove index",index)
  console.log("Form Remove control",this.organizations)
  // let index=this.contacts.indexOf(contact);
  // this.contacts.splice(index,1);
}


onAddOrganization(orgName:string) {
  (<FormArray>this.institutionalRolesForm.get('lms')).push(
    new FormGroup({
      'lms':new FormControl(orgName)
      // 'amount': new FormControl(null, [
      //   Validators.required,
      //   Validators.pattern(/^[1-9]+[0-9]*$/)
      // ])
    })
  );
  let organization=new DataOrg(orgName);
  this.organizations.push(organization)
}



onSubmit(formName:NgForm,ids:Number){
  if(this.editMode){
    const value=formName.value;
    const institutionalModel = new InstitutionalRoles(value.language,
                                this.organizations,
                               value.code,
                               value.name,
                               value.effectiveDate,
                               value.endDate,
                               'value.createBy',
                               'value.createDate',
                               'value.modifiedBy',
                               'value.modifiedDate',
                               'value.deletedBy',
                               'value.deletedDate');

   console.log("Edited Data",institutionalModel);
   console.log("id fro submit",this.id);
   
       if(confirm("Do you want to save changes?")== true)
       {
         console.log("Form Data",formName);
         console.log("ids Values",this.idsd);
this.institutionalServ.editInstitutionalRoles(institutionalModel,this.idsd)
   .subscribe(
     (response)=>alert("Successfully Updated"),
     (error)=>console.log(error)
   );
           this.router.navigate(['/view-Institutional-Roles']);

   }
   }
  }
}

