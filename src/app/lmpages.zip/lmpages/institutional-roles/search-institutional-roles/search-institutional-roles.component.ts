import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-institutional-roles',
  templateUrl: './search-institutional-roles.component.html',
  styleUrls: ['./search-institutional-roles.component.css']
})
export class SearchInstitutionalRolesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
