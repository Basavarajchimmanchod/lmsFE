import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-announcement',
  templateUrl: './edit-announcement.component.html',
  styleUrls: ['./edit-announcement.component.css']
})
export class EditAnnouncementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
