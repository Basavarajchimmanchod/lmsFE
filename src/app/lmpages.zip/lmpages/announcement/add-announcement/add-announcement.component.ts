import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-announcement',
  templateUrl: './add-announcement.component.html',
  styleUrls: ['./add-announcement.component.css']
})
export class AddAnnouncementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
