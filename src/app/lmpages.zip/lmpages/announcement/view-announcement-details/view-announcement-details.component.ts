import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-announcement-details',
  templateUrl: './view-announcement-details.component.html',
  styleUrls: ['./view-announcement-details.component.css']
})
export class ViewAnnouncementDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
