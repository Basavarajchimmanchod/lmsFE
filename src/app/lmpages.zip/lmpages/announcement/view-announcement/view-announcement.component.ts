import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-announcement',
  templateUrl: './view-announcement.component.html',
  styleUrls: ['./view-announcement.component.css']
})
export class ViewAnnouncementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
