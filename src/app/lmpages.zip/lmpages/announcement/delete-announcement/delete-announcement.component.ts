import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-announcement',
  templateUrl: './delete-announcement.component.html',
  styleUrls: ['./delete-announcement.component.css']
})
export class DeleteAnnouncementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
