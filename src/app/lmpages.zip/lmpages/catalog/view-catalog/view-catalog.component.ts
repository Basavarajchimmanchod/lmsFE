import { Component, OnInit } from '@angular/core';
import { AddserviceService } from '../../../service/addservice.service';
import { Response } from '@angular/http';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import { Subscription } from 'rxjs/Subscription';

import { Course } from '../../courses/course.model';
import { CoursesService } from '../../courses/courses.service';

@Component({
  selector: 'app-view-catalog',
  templateUrl: './view-catalog.component.html',
  styleUrls: ['./view-catalog.component.css']
})
export class ViewCatalogComponent implements OnInit {

  Coursesd=[
    {
    }
    ];
  
    coursess:Course[];
    coursesss:Course;
  
    subscription: Subscription;
    id:number;
  
    constructor(private courseServices: AddserviceService,
                private route: ActivatedRoute,
                private router: Router,
                private coursesServicess:CoursesService) { }
  
    ngOnInit() {
      this.coursesServicess.getCoursess()
      this.subscription = this.coursesServicess.coursesChanged
        .subscribe(
          (coursess: Course[]) => {
            this.Coursesd = coursess;
          }
        );
      this.coursess = this.coursesServicess.getCourses();
  
     }
  
   ngOnDestroy() {
      this.subscription.unsubscribe();
    }

  }
  