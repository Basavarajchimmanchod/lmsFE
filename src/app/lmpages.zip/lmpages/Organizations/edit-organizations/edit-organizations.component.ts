import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-organizations',
  templateUrl: './edit-organizations.component.html',
  styleUrls: ['./edit-organizations.component.css']
})
export class EditOrganizationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
