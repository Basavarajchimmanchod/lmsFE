import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, Params, Router } from '@angular/router';
import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';

import { AddserviceService } from '../../../service/addservice.service'

@Component({
  selector: 'app-delete-organizations',
  templateUrl: './delete-organizations.component.html',
  styleUrls: ['./delete-organizations.component.css']
})
export class DeleteOrganizationsComponent implements OnInit {

 
  constructor(private router: Router) { }

  ngOnInit() {
    this.onDeleteOrganization();
  }
public onDeleteOrganization() {

  if(confirm("Are You sure You want You Delete?")== true)
  {
    alert("Record Deleted");
    this.router.navigate(['/view-Organizations']);

  // console.log("deleteid",this.id)
    // this.TermServices.deleteterm(this.id).subscribe(res => {
    //   console.log('Deleted');
    // }
    // );
    //                     this.router.navigate(['/view-Term']);
  }
else

{
                    this.router.navigate(['/view-Organizations']);

}
}
}
