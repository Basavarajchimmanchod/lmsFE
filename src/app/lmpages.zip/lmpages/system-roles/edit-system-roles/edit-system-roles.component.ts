import { Component, OnInit } from '@angular/core';
import { DataOrg } from '../../../Shared/dataOrg';

import { ActivatedRoute, Params, Router } from '@angular/router';
import { FormGroup, FormControl, FormArray, Validators, NgForm } from '@angular/forms';

import { SystemRolesService } from '../system-roles.service';
import { SystemRoles } from '../systemRoles.model';


@Component({
  selector: 'app-edit-system-roles',
  templateUrl: './edit-system-roles.component.html',
  styleUrls: ['./edit-system-roles.component.css']
})
export class EditSystemRolesComponent implements OnInit {

  id: number;
  ids:number;
  editMode = false;
  systemRolesForm: FormGroup;
  public  idsd:number=0;

  language=['English',
            'Chinese - China',
            'English - Australia',
            'English - United Kingdom',
            'Francais - Canada',
            'German - Germany',
            'Italian - Italy',
            'Portuguese - Brazil',
            'Espariol - Mexico'
          ];
          
          organizationd=[]
          organizations:Array<DataOrg>;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private systemRolesS:SystemRolesService
  ) {
    this.organizations=[];
   }

  ngOnInit() {
    this.route.params
      .subscribe(
        (params: Params) => {
          this.id = params['id'];
          this.editMode = params['id'] != null;
    this.initForm();
        }
      );
      console.log("init-id",this.id++)
       this.idsd=this.id
            console.log("init-ids----",this.idsd)

            
            this.systemRolesS.getOrganizations()
            .subscribe(
              (data: any[])=>{
                //console.log(data); 
                this.organizationd=data
        
              },
             (error)=> console.log(error)
            );

  }

onadd2(name)
{
  let organizationss=new DataOrg(name);
  this.organizationd.push(organizationss);

}
onadd3(name)
{
  let organizationss=new DataOrg(name);
  this.organizationd.push(organizationss);
}



private initForm() {

  let systemRolesLanguage = '';
  let systemRolesLms=new FormArray([]);
  let systemRolesroleId = '';
  let systemRolesroleName = '';
  let systemRolesEffectiveDate='';
  let systemRolesEndDate='';

  

  if (this.editMode) {
    const sustemrolesdata = this.systemRolesS.getSystemRole(this.idsd);
    console.log(" Edit form ",sustemrolesdata)

//     systemRolesLanguage=sustemrolesdata.language;

//     if(sustemrolesdata['organization']){
//       for(let sustemroles of sustemrolesdata.organization){
//        console.log("courses Organizations",sustemroles.orgName)
// this.organizations.push(sustemroles);
// systemRolesLms.push(
//          new FormGroup({
//            'organization':new FormControl(sustemroles.orgName)
//          })
//        )
//       }
//     }

    // systemRolesLms = sustemrolesdata.organization;
    // systemRolesroleId=sustemrolesdata.roleId;
    // systemRolesroleName=sustemrolesdata.roleName;
    // systemRolesEffectiveDate=sustemrolesdata.effectiveDate;
    // systemRolesEndDate=sustemrolesdata.endDate;

    // console.log("institutionalRoles Language",systemRolesLanguage)
    // console.log("institutionalRoles Lms",systemRolesLms)
    // console.log("institutionalRoles Code",systemRolesroleId)
    // console.log("systemRolesroleName",systemRolesroleName)
    // console.log("institutionalRoles EffectiveDate",systemRolesEffectiveDate)
    // console.log("institutionalRoles EndDate",systemRolesEndDate)



}
// this.systemRolesForm = new FormGroup({
//     'language':new FormControl(systemRolesLanguage),
//     'organization': systemRolesLms,
//     'roleId':new FormControl(systemRolesroleId),
//     'roleName':new FormControl(systemRolesroleName),
//     'effectiveDate': new FormControl(systemRolesEffectiveDate),
//     'endDate': new FormControl(systemRolesEndDate),


//   });
}

removeOrganization(index:number)
{

  console.log("index----",index);
  (<FormArray>this.systemRolesForm.get('organization')).removeAt(index);
  this.organizations.splice(index,1);
  console.log("Form Remove index",index)
  console.log("Form Remove control",this.organizations)
  // let index=this.contacts.indexOf(contact);
  // this.contacts.splice(index,1);
}


onAddOrganization(orgName:string) {
  (<FormArray>this.systemRolesForm.get('organization')).push(
    new FormGroup({
      'organization':new FormControl(orgName)
      // 'amount': new FormControl(null, [
      //   Validators.required,
      //   Validators.pattern(/^[1-9]+[0-9]*$/)
      // ])
    })
  );
  let organization=new DataOrg(orgName);
  this.organizations.push(organization)
}



onSubmit(formName:NgForm,ids:Number){
  if(this.editMode){
    const value=formName.value;
const systemRolesModel=new SystemRoles(value.language,
                                        this.organizations,
                                        value.roleId,
                                        value.roleName,
                                        value.effectiveDate,
                                        value.endDate,
                                        'value.createBy',
                                        'value.createDate',
                                        'value.modifiedBy',
                                        'value.modifiedDate',
                                        'value.deletedBy',
                                        'value.deletedDate'
                                        )

   console.log("Edited Data",systemRolesModel);
   console.log("id fro submit",this.id);
   
       if(confirm("Do you want to save changes?")== true)
       {
         console.log("Form Data",formName);
         console.log("ids Values",this.idsd);
this.systemRolesS.editSystemRoles(systemRolesModel,this.idsd)
   .subscribe(
     (response)=>alert("Successfully Updated"),
     (error)=>console.log(error)
   );
           this.router.navigate(['/view-System-Roles']);

   }
   }
  }
}
