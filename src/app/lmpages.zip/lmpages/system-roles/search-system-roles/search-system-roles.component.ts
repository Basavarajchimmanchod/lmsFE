import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-system-roles',
  templateUrl: './search-system-roles.component.html',
  styleUrls: ['./search-system-roles.component.css']
})
export class SearchSystemRolesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
