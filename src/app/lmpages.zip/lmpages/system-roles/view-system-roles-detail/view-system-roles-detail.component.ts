import { Component, OnInit } from '@angular/core';
import { DataOrg } from '../../../Shared/dataOrg';

import { ActivatedRoute, Params, Router } from '@angular/router';
import { FormGroup, FormControl, FormArray, Validators, NgForm } from '@angular/forms';

import { SystemRolesService } from '../system-roles.service';
import { SystemRoles } from '../systemRoles.model';

@Component({
  selector: 'app-view-system-roles-detail',
  templateUrl: './view-system-roles-detail.component.html',
  styleUrls: ['./view-system-roles-detail.component.css']
})
export class ViewSystemRolesDetailComponent implements OnInit {

  id: number;
  ids:number;
  editMode = false;
  systemRolesForm: FormGroup;
  public  idsd:number=0;

  language=['English',
            'Chinese - China',
            'English - Australia',
            'English - United Kingdom',
            'Francais - Canada',
            'German - Germany',
            'Italian - Italy',
            'Portuguese - Brazil',
            'Espariol - Mexico'
          ];
          
          organizationd=[]
          organizations:Array<DataOrg>;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private systemRolesS:SystemRolesService
  ) {
    this.organizations=[];
   }

  ngOnInit() {
    this.route.params
      .subscribe(
        (params: Params) => {
          this.id = params['id'];
          this.editMode = params['id'] != null;
    this.initForm();
        }
      );
      console.log("init-id",this.id++)
       this.idsd=this.id
            console.log("init-ids----",this.idsd)
  }

onadd2(name)
{
  let organizationss=new DataOrg(name);
  this.organizationd.push(organizationss);

}
onadd3(name)
{
  let organizationss=new DataOrg(name);
  this.organizationd.push(organizationss);
}
removeOrganization(organizationd)
{
  let index=this.organizationd.indexOf(organizationd);
  this.organizationd.splice(index,1);
}
private initForm() {

  let systemRolesLanguage = '';
  let systemRolesLms=new FormArray([]);
  let systemRolesroleId = '';
  let systemRolesroleName = '';
  let systemRolesEffectiveDate='';
  let systemRolesEndDate='';

  

  if (this.editMode) {
    const sustemrolesdata = this.systemRolesS.getSystemRole(this.id);
    console.log(" Edit form ",sustemrolesdata)

    systemRolesLanguage=sustemrolesdata.language;

    if(sustemrolesdata['organization']){
      for(let sustemroles of sustemrolesdata.organization){
       console.log("courses Organizations",sustemroles.orgName)
this.organizations.push(sustemroles);
systemRolesLms.push(
         new FormGroup({
           'organization':new FormControl(sustemroles.orgName)
         })
       )
      }
    }

    // systemRolesLms = sustemrolesdata.organization;
    systemRolesroleId=sustemrolesdata.roleId;
    systemRolesroleName=sustemrolesdata.roleName;
    systemRolesEffectiveDate=sustemrolesdata.effectiveDate;
    systemRolesEndDate=sustemrolesdata.endDate;

    console.log("institutionalRoles Language",systemRolesLanguage)
    console.log("institutionalRoles Lms",systemRolesLms)
    console.log("institutionalRoles Code",systemRolesroleId)
    console.log("systemRolesroleName",systemRolesroleName)
    console.log("institutionalRoles EffectiveDate",systemRolesEffectiveDate)
    console.log("institutionalRoles EndDate",systemRolesEndDate)



}
this.systemRolesForm = new FormGroup({
    'language':new FormControl(systemRolesLanguage),
    'organization': systemRolesLms,
    'roleId':new FormControl(systemRolesroleId),
    'roleName':new FormControl(systemRolesroleName),
    'effectiveDate': new FormControl(systemRolesEffectiveDate),
    'endDate': new FormControl(systemRolesEndDate),


  });
}

}
