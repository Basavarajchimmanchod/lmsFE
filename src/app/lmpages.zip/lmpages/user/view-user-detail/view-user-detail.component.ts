import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-user-detail',
  templateUrl: './view-user-detail.component.html',
  styleUrls: ['./view-user-detail.component.css']
})
export class ViewUserDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
