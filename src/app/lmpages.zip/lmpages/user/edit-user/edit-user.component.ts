import { Component, OnInit } from '@angular/core';
import { MultiDataCont } from '../../../Shared/multiDataCont';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {

languages=['English',
            'Chinese - China',
            'English - Australia',
            'English - United Kingdom',
            'Francais - Canada',
            'German - Germany',
            'Italian - Italy',
            'Portuguese - Brazil',
            'Espariol - Mexico'
          ];
          
          country=['india',
                    'China',
                    'Australia',
                    'United Kingdom',
                    'Canada',
                    'Germany',
                    'Italy',
                    'Brazil'
          ]
          organizationd=[]
          organizations:Array<MultiDataCont>;
  constructor() { }

  ngOnInit() {
  }

  onadd2(name)
  {
    let organizationss=new MultiDataCont(name);
    this.organizationd.push(organizationss);
  
  }
  onadd3(name)
  {
    let organizationss=new MultiDataCont(name);
    this.organizationd.push(organizationss);
  }
  removeOrganization(organizationd)
  {
    let index=this.organizationd.indexOf(organizationd);
    this.organizationd.splice(index,1);
  }
}
