import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, Params, Router } from '@angular/router';
import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';

import { AddserviceService } from '../../../service/addservice.service'

@Component({
  selector: 'app-delete-user',
  templateUrl: './delete-user.component.html',
  styleUrls: ['./delete-user.component.css']
})
export class DeleteUserComponent implements OnInit {

   constructor(private router: Router) { }

  ngOnInit() {
    this.onDeleteDisciplines();
  }
public onDeleteDisciplines() {

  if(confirm("Are You sure You want You Delete?")== true)
  {
    alert("Record Deleted");
    this.router.navigate(['/view-User']);

  // console.log("deleteid",this.id)
    // this.TermServices.deleteterm(this.id).subscribe(res => {
    //   console.log('Deleted');
    // }
    // );
    //                     this.router.navigate(['/view-Term']);
  }
else

{
                    this.router.navigate(['/view-User']);

}
}
}
