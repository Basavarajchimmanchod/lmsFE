import { Component, OnInit, AfterViewInit, ViewEncapsulation } from '@angular/core';
import { ScriptLoaderService } from '../../../_services/script-loader.service';

import { ActivatedRoute, Params, Router } from '@angular/router';
import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';

import { TermsService } from '../terms.service'
import { NgForm } from '@angular/forms';
import { AddserviceService } from '../../../service/addservice.service'

import { Term } from '../term.model';

@Component({
  selector: 'app-edit-term',
  templateUrl: './edit-term.component.html',
  styleUrls: ['./edit-term.component.css']
})
export class EditTermComponent implements OnInit {

  id: number;
  ids:number;
  editMode = false;
  termForm: FormGroup;
  
public  idsd:number=0;
  constructor(private router: Router,
              private route: ActivatedRoute,
              private termServicess:TermsService,
              private TermAddService:AddserviceService
              ) { }

  ngOnInit() {
    this.route.params
      .subscribe(
        (params: Params) => {
          this.id = params['id'];
          this.editMode = params['id'] != null;
    this.initForm();
        }
      );
      console.log("init-id",this.id++)
       this.idsd=this.id
            console.log("init-ids----",this.idsd)

  }
  private initForm() {
    let termTermName = '';
    let termTermDescription  = '';
    let termStartDate ;
    let termendDate ;
    
    

    if (this.editMode) {
      const termsd = this.termServicess.getTerm(this.id);
      console.log(" Edit form ",termsd)
      termTermName=termsd.termName;
      termTermDescription = termsd.termDescription;
      termStartDate=termsd.startDate;
      termendDate=termsd.endDate;
      console.log("Term Name",termTermName)
      console.log("Term Description",termTermDescription)
      console.log("Term StartDate",termStartDate)
      console.log("Term EndDate",termendDate)
      


  }
  this.termForm = new FormGroup({
      'termName':new FormControl(termTermName,Validators.required),
      'termDescription': new FormControl(termTermDescription),
      'startDate':new FormControl(termStartDate),
      'endDate': new FormControl(termendDate),
      

    });
  }
  ngAfterViewInit() {
  }


  onSubmit(forname:NgForm,ids:number){
    if(this.editMode){
    const value=forname.value;
     const termModel = new Term(value.termName,
                                value.termDescription,
                                'value.duration',
                                value.startDate,
                                value.endDate,
                                'value.createBy',
                                'value.createDate',
                                'value.modifiedBy',
                                'value.modifiedDate',
                                'value.deletedBy',
                                'value.deletedDate');

    console.log("Edited Data",termModel);
    console.log("id fro submit",this.id);
    
        if(confirm("Do you want to save changes?")== true)
        {
this.termServicess.editterm(termModel,this.id)
    .subscribe(
      (response)=>alert("Successfully Updated"),
      (error)=>console.log(error)
    );
            this.router.navigate(['/view-Term']);

    }
    }

  }

}
