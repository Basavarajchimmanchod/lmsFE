import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

import { Subscription } from 'rxjs/Subscription';

import { TermsService } from '../terms.service';
import { Term } from '../term.model';

import { AddserviceService } from '../../../service/addservice.service';

@Component({
  selector: 'app-search-term',
  templateUrl: './search-term.component.html',
  styleUrls: ['./search-term.component.css']
})
export class SearchTermComponent implements OnInit {
  termsd=[];
terms:Term[];
termss: Term;

subscription: Subscription;
id:number;

isDisable=false;
  constructor( private termServicess:AddserviceService) { }

  ngOnInit() {

  }

  
  onSubmit(form:NgForm){
    const value=form.value

    const name=value.termName

    // const termsd = this.termServicess.getTermName(name);
    // this.termServicess.getTermName(name)

    // this.subscription = this.termServicess.termsChanged
    // .subscribe(
    //   (terms: Term[]) => {
    //     this.termsd = terms;
    //   }
    // );
   this.termServicess.getTerms(name)
   .subscribe(
     (data)=>{
this.termsd=data
     }
   );
this.onDisable();
    }
    onDisable(){
      this.isDisable=true;
    }
  }

 

