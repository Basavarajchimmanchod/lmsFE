import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-information',
  templateUrl: './course-information.component.html',
  styleUrls: ['./course-information.component.css']
})
export class CourseInformationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
