import { Component, OnInit, AfterViewInit, ViewEncapsulation } from '@angular/core';
import { ScriptLoaderService } from '../../../_services/script-loader.service';
import { MultiDataCont } from '../../../Shared/multiDataCont';
import { DataOrg } from '../../../Shared/dataOrg';



import { ActivatedRoute, Params, Router } from '@angular/router';
import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';

import { CoursesService } from '../courses.service'
import { NgForm } from '@angular/forms';
import { AddserviceService } from '../../../service/addservice.service';

import { Course } from '../course.model';


@Component({
  selector: 'app-edit-course',
  templateUrl: './edit-course.component.html',
  styleUrls: ['./edit-course.component.css']
})
export class EditCourseComponent implements OnInit, AfterViewInit {

  contentss=[
      {

      }
    ]
organizationd=[]
    disciplinesd=[
      {

      }
    ]

  Languages=['English',
            'Chinese - China',
            'English - Australia',
            'English - United Kingdom',
            'Francais - Canada',
            'German - Germany',
            'Italian - Italy',
            'Portuguese - Brazil',
            'Espariol - Mexico'
          ];

  
  major=['NXT Shared Major',
            'Programming'
          ];

  deliveryMethod=['Assessment',
          'Classroom',
          'Course Group',
          'eLearning',
          'Self-Study'
        ];

  Content_type=['Resource',
        'link'
      ];


  approval=['Yes','no'];
  relaunch=['Yes','no'];

  
  resource=['None',
            'CSE Content(Inactive)'
      ];


  Certified=['Yes','No'];
  Completion=['Yes','No'];

  Enrollment=['Once only',
              'Unlimited',
              'Restrict by number of days',
              'Restrict by number of enrollments'
            ];

  accumulate=['Yes','No'];

  non_subscribers=['Yes','No'];
  alluse_ofinterest=['Yes','No'];
  instructionallanguages=['Chinese - China',
                          'Français - Canada',
                          'German - Germany',
                          'Japanese - Japan',
                          'Español - México',
                          'Dutch - The Netherlands',
                          'Portuguese - Brazil ',
                          'English',
                          'Français - France',
                          'Italian - Italy',
                          'Korean - Korea',
                          'Spanish - Spain',
                          'Polish - Poland',
                          'Russian - Russia',
                        ];
  
  subscriptions=['SUB01',
                  'SUB02'
                  ];
  errorMsg = '';
  status=['Active','Inactive'];

   id: number;
  ids:number;
  editMode = false;
  coursesForm: FormGroup;
  
public  idsd:number=0;
  name:string;
  contacts:Array<MultiDataCont>;
  organizations:Array<DataOrg>;

  public isCollapsed=true;
  constructor(private _script: ScriptLoaderService,
              private router: Router,
              private route: ActivatedRoute,
              private CoursesServicesS:CoursesService,
              private courseServices:AddserviceService
             ) {
    this.contacts=[];
    this.organizations=[];

   }

  ngOnInit() {
    this.route.params
      .subscribe(
        (params: Params) => {
          this.id = params['id'];
          this.editMode = params['id'] != null;
    this.initForm();
        }
      );
      console.log("init-id",this.id)
       this.idsd=this.id
            console.log("init-ids----",this.idsd)
this.CoursesServicesS.getContent()
    .subscribe(
      (data: any[])=>{
        //console.log(data); 
        this.contentss=data

      },
     (error)=> console.log(error)
    );
    
     this.CoursesServicesS.getDiscipline()
    .subscribe(
      (data: any[])=>{
        //console.log(data); 
        this.disciplinesd=data

      },
     (error)=> console.log(error)
    );
    
  }
// console.log("idb  value",idb);
  private initForm() {

    let courseOrganizations=new FormArray([]);
    let courseCode="";
    let courseName="";
    let courseTuition;
    let courseDescription="";
    let courseTargetedLearners="";
    let courseDuration="";
    let courseMajor="";
    let courseDeliveryMethod="";
    let courseApprovalRequired="";
    let courseCanRelaunch;
    let courseContentType="";
    let courseResourceContent="";
    let courseSelfCertifiedCompletion="";
    let courseCourseCompletionCertificate="";
    let courseStatus="";
    let courseContent=new FormArray([]);
    let courseLanguage = "";
    let courseNotes = "";
    let courseDisplayDate = "";
    let courseEnrollmentOpenDate = "";
    let courseEnrollmentCloseDate= "";
    let ccourseHideDate = "";
    let courseCertificationCalculationDate = "";
    let courseDaysStdToCompl;
    let courseDaysBeforeStdToCompl;
    let courseExpireDays;
    let courseRemindStudent;
    let courseEnrollmentRestriction="";
    let courseEnrollmentDays;
    let courseAccumulateCredit="";
    let courseCredit="";
    let courseSubscriptionProgram="";
    let courseNonSubscriptionCanEnroll="";
    let courseInstructionalLanguages="";
    let courseVersion="";
    let courseAllowUseOfInterestLists="";
    

    if (this.editMode) {
      const courseds = this.CoursesServicesS.getCourse(this.id);
      console.log(" Edit form ",courseds)

      if(courseds['organizations']){
        for(let organizations of courseds.organizations){
         console.log("courses Organizations",organizations.orgName)
 this.organizations.push(organizations);
 courseOrganizations.push(
           new FormGroup({
             'organizations':new FormControl(organizations.orgName)
           })
         )
        }
      }

    //  courseOrganizations=courseds.organizations;
     courseCode=courseds.code;
     courseName=courseds.name;
     courseTuition=courseds.tuition;
     courseDescription=courseds.description;
     courseTargetedLearners=courseds.targetedLearners;
     courseDuration=courseds.duration;
     courseMajor=courseds.major;
     courseDeliveryMethod=courseds.deliveryMethod;
     courseApprovalRequired=courseds.approvalRequired;
     courseCanRelaunch=courseds.canRelaunch;
     courseContentType=courseds.contentType;
     courseResourceContent=courseds.resourceContent;
     courseSelfCertifiedCompletion=courseds.selfCertifiedCompletion;
     courseCourseCompletionCertificate=courseds.courseCompletionCertificate;
     courseStatus=courseds.status;

     if(courseds['content']){
      for(let contacts of courseds.content){
       console.log("courses Content23556",contacts.contName)
this.contacts.push(contacts);
courseContent.push(
         new FormGroup({
           'content':new FormControl(contacts.contName)
         })
       )
      }
    }


    //  courseContent=courseds.content;
     courseLanguage = courseds.language;
     courseNotes = courseds.notes;
     courseDisplayDate = courseds.courseDisplayDate;
     courseEnrollmentOpenDate = courseds.enrollmentOpenDate;
     courseEnrollmentCloseDate= courseds.enrollmentCloseDate;
     ccourseHideDate = courseds.courseHideDate;
     courseCertificationCalculationDate = courseds.certificationCalculationDate;
     courseDaysStdToCompl=courseds.daysStdToCompl;
     courseDaysBeforeStdToCompl=courseds.daysBeforeStdToCompl;
     courseExpireDays=courseds.expireDays;
     courseRemindStudent=courseds.remindStudent;
     courseEnrollmentRestriction=courseds.enrollmentRestriction;
     courseEnrollmentDays=courseds.enrollmentDays;
     courseAccumulateCredit=courseds.accumulateCredit;
     courseCredit=courseds.credit;
     courseSubscriptionProgram=courseds.subscriptionProgram;
     courseNonSubscriptionCanEnroll=courseds.nonSubscriptionCanEnroll;
     courseInstructionalLanguages=courseds.instructionalLanguages;
     courseVersion=courseds.version;
     courseAllowUseOfInterestLists=courseds.allowUseOfInterestLists;
    
    console.log("courseHidedate------",courseVersion)
    //   ""courseLanguage=categoriesds.language;
    //   courseName = categoriesds.name;
    //   categoriesDescription=categoriesds.description;
    //   categoriesStartDate=categoriesds.startDate;
    //   categoriesEndDate=categoriesds.endDate;
    //   categoriesLms=categoriesds.lms;
    //  categoriesIsCategorySearchable=categoriesds.isCategorySearchable
    //  categoriesStatus=categoriesds.status""

    //  // categoriesisCategorySearchable.isCategorySearchable;
    //  console.log("categorieslanguage",categoriesLanguage)
    //       console.log("categoriesname",categoriesName)
    //       console.log("categoriesdescription",categoriesDescription)
    //       console.log("categoriesstartDate",categoriesStartDate)
    //       console.log("categoriesendDate",categoriesEndDate)
    //       console.log("categorieslms",categoriesLms)
    //       console.log("categoriesisCategorySearchable",categoriesIsCategorySearchable)



  }
  this.coursesForm = new FormGroup({
    'organizations':courseOrganizations,
    'code':new FormControl(courseCode),
    'name':new FormControl(courseName),
    'tuition':new FormControl(courseTuition),
    'description':new FormControl(courseDescription),
    'targetedLearners':new FormControl(courseTargetedLearners),
    'duration':new FormControl(courseDuration),
    'major':new FormControl(courseMajor),
    'deliveryMethod':new FormControl(courseDeliveryMethod),
    'approvalRequired':new FormControl(courseApprovalRequired),
    'canRelaunch':new FormControl(courseCanRelaunch),
    'contentType':new FormControl(courseContentType),
    'resourceContent':new FormControl(courseResourceContent),
    'selfCertifiedCompletion':new FormControl(courseSelfCertifiedCompletion),
    'courseCompletionCertificate':new FormControl(courseCourseCompletionCertificate),
    'status':new FormControl(courseStatus),
    'content':courseContent,
    'language':new FormControl(courseLanguage),
    'notes':new FormControl(courseNotes),
    'courseDisplayDate':new FormControl(courseDisplayDate),
    'enrollmentOpenDate':new FormControl(courseEnrollmentOpenDate),
    'enrollmentCloseDate':new FormControl(courseEnrollmentCloseDate),
    'courseHideDate':new FormControl(ccourseHideDate),
    'certificationCalculationDate':new FormControl(courseCertificationCalculationDate),
    'daysStdToCompl':new FormControl(courseDaysStdToCompl),
    
    'daysBeforeStdToCompl':new FormControl(courseDaysBeforeStdToCompl),
    'expireDays':new FormControl(courseExpireDays),
    'remindStudent':new FormControl(courseRemindStudent),
    'enrollmentRestriction':new FormControl(courseEnrollmentRestriction),
    'enrollmentDays':new FormControl(courseEnrollmentDays),
    'accumulateCredit':new FormControl(courseAccumulateCredit),
    'credit':new FormControl(courseCredit),
    'subscriptionProgram':new FormControl(courseSubscriptionProgram),
    'nonSubscriptionCanEnroll':new FormControl(courseNonSubscriptionCanEnroll),
    'allowUseOfInterestLists':new FormControl(courseAllowUseOfInterestLists),
    'version':new FormControl(courseVersion),

    'instructionalLanguages':new FormControl(courseInstructionalLanguages),

    //  courseHideDate = courseds.courseHideDate;
    //  courseCertificationCalculationDate = courseds.certificationCalculationDate;
    //  courseDaysStdToCompl=courseds.daysStdToCompl;
    //  courseDaysBeforeStdToCompl=courseds.daysBeforeStdToCompl;
    //  courseExpireDays=courseds.expireDays;
    //  courseRemindStudent=courseds.remindStudent;
    //  courseEnrollmentRestriction=courseds.enrollmentRestriction;
    //  courseEnrollmentDays=courseds.enrollmentDays;
    //  courseAccumulateCredit=courseds.accumulateCredit;
    //  courseCredit=courseds.credit;
    //  courseSubscriptionProgram=courseds.subscriptionProgram;
    //  courseNonSubscriptionCanEnroll=courseds.nonSubscriptionCanEnroll;
    //  courseInstructionalLanguages=courseds.instructionalLanguages;
    //  courseVersion=courseds.version;
    //  courseAllowUseOfInterestLists=courseds.allowUseOfInterestLists;
    
     });
  

  }

  ngAfterViewInit() {
    this._script.load('./assets/js/scripts/form-plugins.js');
  }

  onAdd(name)
  {
   let contact=new MultiDataCont(name);
    this.contacts.push(contact);

  }
  onadd2(name)
  {
    let organizationss=new DataOrg(name);
    this.organizationd.push(organizationss);

  }
  onadd3(name)
  {
    let organizationss=new DataOrg(name);
    this.organizationd.push(organizationss);
  }
  removeOrganization(organizationd)
  {
    let index=this.contacts.indexOf(organizationd);
    this.organizationd.splice(index,1);
  }
  // onadd2(name)
  // {
  //   let contact=new Contact(name);
  //   this.contacts.push(contact);

  // }
  // onadd3(name)
  // {
  //  let contact=new Contact(name);
  //   this.contacts.push(contact);
  // }
  addContact(Contact)
  {
    let contact=new Contact(name);
    this.contacts.push(contact);

  }
  removeContact(contact)
  {
    let index=this.contacts.indexOf(contact);
    this.contacts.splice(index,1);
  }

  removeOrganisation(contact)
  {
    let index=this.organizationd.indexOf(contact);
    this.organizationd.splice(index,1);
  }

  
  onSubmit(form: NgForm) {
        if(this.editMode){
    const value=form.value
  const CourseModel=new Course(this.organizations,
                                value.code,
                                value.name,
                                value.tuition,
                                value.description,
                                value.targetedLearners,
                                value.duration,
                                value.major,
                                value.deliveryMethod,
                                value.approvalRequired,
                                value.canRelaunch,
                                value.contentType,
                                value.resourceContent,
                                value.selfCertifiedCompletion,
                                value.courseCompletionCertificate,
                                value.status,
                                this.contacts,
                                value.language,
                                value.notes,
                                value.courseDisplayDate,
                                value.enrollmentOpenDate,
                                value.enrollmentCloseDate,
                                value.courseHideDate,
                                value.certificationCalculationDate,
                                value.daysStdToCompl,
                                value.daysBeforeStdToCompl,
                                value.expireDays,
                                value.remindStudent,
                                value.enrollmentRestriction,
                                value.enrollmentdays,
                                value.accumulateCredit,
                                value.credit,
                                value.subscriptionProgram,
                                value.nonSubscriptionCanEnroll,
                                value.instructionalLanguages,
                                value.version,
                                value.allowUseOfInterestLists,
                                'value.createBy',
                                'value.createDate',
                                'value.modifiedBy',
                                'value.modifiedDate',
                                'value.deletedBy',
                                'value.deletedDate'
                                )
console.log("Edited Data",CourseModel);
    console.log("id fro submit",this.id);

      if(confirm("Do you want to save changes?")== true)
        {
    this.CoursesServicesS.editCourse(CourseModel,this.id)
    .subscribe(
      (response)=>alert("Successfully Updated"),
      (error)=>alert(error)
    );
              this.router.navigate(['/view-courses']);

    }
        }
  }
onDeleteCategorie(){
      this.route.params
      .subscribe(
        (params: Params) => {
          this.ids = params['id'];
          this.editMode = params['id'] != null;
      // this.courseServices.deletecategories(this.ids)
  }
      );
      console.log("Delete function id",this.ids)
}


}
